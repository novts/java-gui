import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class Main {

    public static void main(String[] args) {
        final JFrame myFrame = new JFrame("JTextPane HTML");
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setSize(600,600);
        final JTextPane myPane = new JTextPane();
        myFrame.setContentPane(myPane);

        DefaultStyledDocument document = new DefaultStyledDocument();
        StyleContext context = new StyleContext();
        // build a style
        Style style = context.addStyle("test", null);
        // set some style properties
        StyleConstants.setForeground(style, Color.BLUE);
        try {
            document.insertString(0, "Styled string \n", style);
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
        myPane.setStyledDocument(document);

        JMenuBar myBar = new JMenuBar();
        JMenu myMenu = new JMenu("File");
        JMenuItem myItem = new JMenuItem("Open");
        myItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myPane.setContentType("text/html");
                JFileChooser  fileDialog = new JFileChooser();
                int returnVal = fileDialog.showOpenDialog(myFrame);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    java.io.File file = fileDialog.getSelectedFile();
                    try {
                        String text = new String(Files.readAllBytes(file.toPath()));
                        myPane.setText(text);
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });
        myMenu.add(myItem);

        myItem = new JMenuItem("Save");
        myItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setCurrentDirectory(new File("/Users/user"));
                int retrival = chooser.showSaveDialog(null);
                if (retrival == JFileChooser.APPROVE_OPTION) {
                    try {
                        Files.write(chooser.getSelectedFile().toPath(), myPane.getText().getBytes());
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });
        myMenu.add(myItem);
        myBar.add(myMenu);

        myMenu = new JMenu("View");
        ButtonGroup myGroup = new ButtonGroup();
        myItem = new JRadioButtonMenuItem("HTML");
        myItem.setSelected(true);
        myItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String   text = myPane.getText();
                myPane.setContentType("text/html");
                myPane.setText(text);
            }
        });
        myMenu.add(myItem);
        myGroup.add(myItem);

        myItem = new JRadioButtonMenuItem("Plain");
        myItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = myPane.getText();
                myPane.setContentType("text/plain");
                myPane.setText(text);
            }
        });
        myMenu.add(myItem);
        myGroup.add(myItem);

        myBar.add(myMenu);

        myFrame.setJMenuBar(myBar);
        myFrame.setVisible(true);
    }
}
