import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

import static java.awt.Component.CENTER_ALIGNMENT;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(null);

        JLabel label = new JLabel("Border", SwingConstants.CENTER);
        label.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        label.setBorder(BorderFactory.createLineBorder(Color.BLUE,5,true));
        label.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLUE,Color.GRAY));
        label.setBorder(BorderFactory.createSoftBevelBorder(BevelBorder.RAISED, Color.BLUE,Color.GRAY));
        label.setBorder(BorderFactory.createEtchedBorder(BevelBorder.RAISED, Color.BLUE,Color.GRAY));
        label.setBorder(BorderFactory.createTitledBorder("Title"));
        label.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(BevelBorder.RAISED, Color.BLUE,Color.GRAY),"Title", TitledBorder.CENTER, TitledBorder.TOP,new Font("TimesRoman", Font.BOLD, 12),Color.MAGENTA));
        label.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Title"),BorderFactory.createLineBorder(Color.BLUE,5,true)));
        label.setBorder(BorderFactory.createDashedBorder(Color.BLUE, 10, 5));
        label.setBorder(BorderFactory.createStrokeBorder(new BasicStroke(5),Color.red));

        label.setBounds(100,50,100,50);
        label.setOpaque(true);
        label.setBackground(Color.GREEN);
        frame.add(label);
        frame.setVisible(true);
    }
}
