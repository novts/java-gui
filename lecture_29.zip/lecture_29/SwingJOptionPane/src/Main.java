import javax.swing.*;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setVisible(true);

       /* JOptionPane.showMessageDialog(frame,"Hello!", "Message", JOptionPane.INFORMATION_MESSAGE);

        JOptionPane.showMessageDialog(frame,"Hello!", "WARNING", JOptionPane.WARNING_MESSAGE);

        JOptionPane.showMessageDialog(frame,"Hello!", "ERROR", JOptionPane.ERROR_MESSAGE);

        JOptionPane.showMessageDialog(frame,"Hello?", "QUESTION", JOptionPane.QUESTION_MESSAGE);

        JOptionPane.showMessageDialog(frame,"Hello!", "PLAIN", JOptionPane.PLAIN_MESSAGE);*/

      //  String name=JOptionPane.showInputDialog(frame,"Enter Name", "Input",  JOptionPane.INFORMATION_MESSAGE);

       /* String[] names = {"name1", "name2", "name3"};
        String name= (String) JOptionPane.showInputDialog(frame,"Enter Name", "Input",  JOptionPane.INFORMATION_MESSAGE, null, names, "name1");
        System.out.println(name);*/

       /* int a=JOptionPane.showConfirmDialog(frame,"Are you sure?", "Confirm", JOptionPane.YES_NO_CANCEL_OPTION);
        if(a==JOptionPane.YES_OPTION){
            frame.dispose();
        }*/

        String[] buttons = {"OK", "NO", "CANCEL"};
        int a = JOptionPane.showOptionDialog(frame,
                "<html><h1>A you sure?</h1></html>",
                "Confirm", JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, buttons, "OK");

        if(a==JOptionPane.YES_OPTION){
            frame.dispose();
        }
    }
}
