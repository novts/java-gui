import javax.swing.*;

import java.awt.*;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        UIManager.LookAndFeelInfo[] info = UIManager.getInstalledLookAndFeels();
        for (int i = 0; i < info.length; i++) {
            System.out.println(info[i].getName());
            System.out.println(info[i].getClassName());
        }
        try {
           // UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
          //  UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
         //   UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
          //  UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");

            javax.swing.plaf.synth.SynthLookAndFeel synth = new javax.swing.plaf.synth.SynthLookAndFeel();
            synth.load(Main.class.getResourceAsStream("synth.xml"), Main.class);
            javax.swing.UIManager.setLookAndFeel(synth);

        } catch (Exception e) {
            e.printStackTrace();
        }

        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(200,200);
        frame.setLayout(new FlowLayout());

     //   frame.add(new JLabel("Label"));
        frame.add(new JButton("Button"));
        frame.add(new JTextArea("TextArea"));

        frame.setVisible(true);

}
}
