import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);

        JToolBar toolbar = new JToolBar("ToolBar",JToolBar.HORIZONTAL);
        JButton button = new JButton("File");
        toolbar.add(button);
        toolbar.addSeparator();
        toolbar.add(new JButton("Edit"));
        toolbar.addSeparator();
        toolbar.add(new JButton("Help"));
        toolbar.setRollover(true);
        Container contentPane = frame.getContentPane();
        contentPane.add(toolbar, BorderLayout.NORTH);

        toolbar.add(new AbstractAction() {
            {
                putValue(NAME, "ACTION");
                putValue(SHORT_DESCRIPTION, "This is Action");
                putValue(MNEMONIC_KEY, KeyEvent.VK_A);
            }
            @Override
            public void actionPerformed(ActionEvent e) {
              System.out.println("This is Action");
            }
        });


        frame.setVisible(true);
    }
}
