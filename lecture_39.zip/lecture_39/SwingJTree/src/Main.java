import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setLayout(new FlowLayout());

        DefaultMutableTreeNode root =new DefaultMutableTreeNode("Style");
        DefaultMutableTreeNode color=new DefaultMutableTreeNode("color");
        DefaultMutableTreeNode font=new DefaultMutableTreeNode("font");
        root.add(color);
        root.add(font);
        DefaultMutableTreeNode red=new DefaultMutableTreeNode("red");
        DefaultMutableTreeNode blue=new DefaultMutableTreeNode("blue");
        DefaultMutableTreeNode black=new DefaultMutableTreeNode("black");
        DefaultMutableTreeNode green=new DefaultMutableTreeNode("green");
        color.add(red); color.add(blue); color.add(black); color.add(green);

        JTree jt=new JTree(root);
        jt.setVisibleRowCount(10);
        jt.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        jt.setEditable(true);

        DefaultTreeCellEditor editor = (DefaultTreeCellEditor)jt.getCellEditor();
        editor.addCellEditorListener(new CellEditorListener() {
            @Override
            public void editingStopped(ChangeEvent e) {
                CellEditor  editor = (CellEditor)e.getSource();
                System.out.println("New value: " + editor.getCellEditorValue().toString());
            }

            @Override
            public void editingCanceled(ChangeEvent e) {

            }
        });

       /* String elements[] = { "red", "blue", "black", "green"} ;
        JComboBox comboBox = new JComboBox(elements);
        comboBox.setEditable(true);
        TreeCellEditor comboEditor = new DefaultCellEditor(comboBox);
        DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer)jt.getCellRenderer();
        TreeCellEditor ed = new DefaultTreeCellEditor(jt, renderer, comboEditor);
        jt.setCellEditor(ed); */


        DefaultTreeModel treeModel = (DefaultTreeModel)jt.getModel();
        treeModel.addTreeModelListener(new TreeModelListener() {
            @Override
            public void treeNodesChanged(TreeModelEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)(e.getTreePath().getLastPathComponent());
                if(!node.isRoot()) {
                    int index = e.getChildIndices()[0];
                    node = (DefaultMutableTreeNode) (node.getChildAt(index));
                }
               // System.out.println("New value: " + node.toString());
            }

            @Override
            public void treeNodesInserted(TreeModelEvent e) {

            }

            @Override
            public void treeNodesRemoved(TreeModelEvent e) {

            }

            @Override
            public void treeStructureChanged(TreeModelEvent e) {

            }
        });

        jt.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                JTree tree = (JTree) e.getSource();
                DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
                String selectedNodeName = selectedNode.toString();
               // System.out.println(selectedNodeName);
            }
        });

        JScrollPane pane = new JScrollPane(jt);
        pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        pane.setPreferredSize(new Dimension(300,300));

        frame.add(pane);
        frame.setVisible(true);
    }
}
