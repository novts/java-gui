import java.awt.*;

import javax.swing.*;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);

        JWindow w = new JWindow(frame);
        w.setSize(300, 300);
        w.setLocation(50, 50);

        w.getContentPane().add(new JLabel("JWindow Example", SwingConstants.CENTER), BorderLayout.CENTER);
        w.getContentPane().setBackground(Color.CYAN);
        w.setVisible(true);

        frame.setVisible(true);

    }
}
