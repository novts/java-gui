import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new FlowLayout());

        final DefaultListModel fruitsName = new DefaultListModel();
        fruitsName.addElement("Apple");
        fruitsName.addElement("Grapes");
        fruitsName.addElement("Mango");
        fruitsName.addElement("Peer");
        final JList fruitList = new JList(fruitsName);
        fruitList.setDragEnabled(true);

        JScrollPane pane = new JScrollPane(fruitList);
        pane.setPreferredSize(new Dimension(100,100));

        JTextArea area = new JTextArea();
        area.setPreferredSize(new Dimension(100,100));

        JLabel label = new JLabel("Label",  JLabel.CENTER);
        label.setPreferredSize(new Dimension(100,20));

        BeanInfo infoLb = null;
        try {
            infoLb = Introspector.getBeanInfo(JLabel.class);
        } catch (IntrospectionException e) {
            e.printStackTrace();
        }
        PropertyDescriptor[] pdsLb = infoLb.getPropertyDescriptors();
        for(PropertyDescriptor pd:pdsLb){
         //   System.out.println("JLabel property: "+pd.getName());
        }

        label.setTransferHandler(new TransferHandler("text"));
        label.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){
                JComponent c = (JComponent)e.getSource();
                TransferHandler th = c.getTransferHandler();
                th.exportAsDrag(c, e, TransferHandler.COPY);
            }
        });

        frame.add(pane);
        frame.add(area);
        frame.add(label);
        frame.setVisible(true);
    }
}
