import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new FlowLayout());

        Object[] headers = { "Name", "Surname", "Telephone" };
        Object[][] data = {
                { "John", "Smith", "1112221" },
                { "Ivan", "Black", "2221111" },
                { "George", "White", "3334444" },
                { "Bolvan", "Black", "2235111" },
                { "Serg", "Black", "2221511" },
                { "Pussy", "Black", "2221111" },
                { "Tonya", "Red", "2121111" },
                { "Elise", "Green", "2321111" },
        };

               /*     Object[][] data = {
                { new User("John", "Smith").getfirstName(), new User("John", "Smith").getsecondtName(), "1112221" },
                { new User("Ivan", "Black").getfirstName(), new User("Ivan", "Black").getsecondtName(), "2221111" },
                { new User("George", "White").getfirstName(), new User("George", "White").getsecondtName(), "3334444" },
                { new User("Bolvan", "Black").getfirstName(), new User("Bolvan", "Black").getsecondtName(), "2235111" },

        };

        JTable table = new JTable(data, headers);*/

        java.util.List<User> dataUser = new ArrayList<User>();
        for (int i=1; i<10; i++) {
            Random random = new Random();
            dataUser.add(new User("FirstName"+random.nextInt(i),"SecondName"+random.nextInt(i)));
        }
        JTable table = new JTable(new Model(dataUser));

       /* table.setAutoCreateRowSorter(true);
        RowSorter sorter = table.getRowSorter();

        java.util.List<RowSorter.SortKey> keys = new ArrayList<RowSorter.SortKey>();
        keys.add(new RowSorter.SortKey(1, SortOrder.DESCENDING));
        sorter.setSortKeys(keys);
        sorter.toggleSortOrder(0);*/

       TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(table.getModel());
       table.setRowSorter(sorter);

        Comparator<String> comparator = new Comparator<String>() {
            public int compare(String s1, String s2) {
                Integer in1 = new Integer(s1.substring(s1.length() - 1));
                Integer in2 = new Integer(s2.substring(s2.length() - 1));
                return -in1.compareTo(in2);
            }
        };

        sorter.setComparator(0, comparator);

        java.util.List<RowSorter.SortKey> keys = new ArrayList<RowSorter.SortKey>();
        keys.add(new RowSorter.SortKey(0, SortOrder.DESCENDING));
        sorter.setSortKeys(keys);

        RowFilter<Object, Object> filter = new RowFilter<Object, Object>() {
            public boolean include(Entry entry) {
                int flag=0;
                for (int i = entry.getValueCount() - 1; i >= 0; i--) {
                    String estr = (String) entry.getValue(i);
                    Integer num = new Integer(estr.substring(estr.length() - 1));
                    flag = flag + num.intValue();
                }
                return flag > 5;
            }
        };

        sorter.setRowFilter(filter);

        JScrollPane pane = new JScrollPane(table);
       // table.setFillsViewportHeight(true);
        table.setPreferredScrollableViewportSize(new Dimension(250, 100));
     //   TableColumn tc = table.getColumnModel().getColumn(0);
     //   tc.setPreferredWidth(150);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        //table.setCellSelectionEnabled(true);
        //table.setRowSelectionAllowed(true);
        table.setColumnSelectionAllowed(true);

       table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (e.getValueIsAdjusting()) return;

                String Data = null;
                int[] row = table.getSelectedRows();
                int[] columns = table.getSelectedColumns();
                for (int i = 0; i < row.length; i++) {
                    for (int j = 0; j < columns.length; j++) {
                        Data = (String) table.getValueAt(row[i], columns[j]);
                     //   System.out.println("Table element selected is: " + Data);
                    } }
            }
        });

        table.getModel().addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {

                System.out.println("Event Type is: " + e.getType());

                TableModel model = (TableModel)e.getSource();
                int row = e.getFirstRow();
                int column = e.getColumn();

                String cellValue = String.valueOf( model.getValueAt(row, column) );

                JOptionPane.showMessageDialog(frame,
                        "Value at (" + row + "," + column + ") changed to " + "\'" + cellValue + "\'");
            }
        });

        table.getColumnModel().addColumnModelListener(new TableColumnModelListener() {
            @Override
            public void columnAdded(TableColumnModelEvent e) {

            }

            @Override
            public void columnRemoved(TableColumnModelEvent e) {

            }

            @Override
            public void columnMoved(TableColumnModelEvent e) {

            }

            @Override
            public void columnMarginChanged(ChangeEvent e) {

            }

            @Override
            public void columnSelectionChanged(ListSelectionEvent e) {
                if (e.getValueIsAdjusting()) return;
                String Data = null;
                int[] row = table.getSelectedRows();
                int[] columns = table.getSelectedColumns();
                for (int i = 0; i < row.length; i++) {
                    for (int j = 0; j < columns.length; j++) {
                        Data = (String) table.getValueAt(row[i], columns[j]);
                       // System.out.println("Table element selected is: " + Data);
                    } }
            }
        });


        CellEditor editor = table.getDefaultEditor(String.class);
      //  DefaultCellEditor editor = new DefaultCellEditor(new JTextField());
       // editor.setClickCountToStart(1);
      //  table.getColumn("Name").setCellEditor(editor);
        editor.addCellEditorListener(new CellEditorListener() {
            @Override
            public void editingStopped(ChangeEvent e) {
                System.out.println("Element value is: " + ((CellEditor)e.getSource()).getCellEditorValue().toString());
            }

            @Override
            public void editingCanceled(ChangeEvent e) {

            }
        });

        DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(String.class);
       // DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
       // TableColumn tc = table.getColumn("Name");
       // tc.setCellRenderer(renderer);
        renderer.setToolTipText("This is String");

        table.getTableHeader().setToolTipText("This is header");

        frame.add(pane);
        frame.setVisible(true);
    }

    public static class Model extends AbstractTableModel {
        private java.util.List data;
        public Model(java.util.List data) {
            this.data = data;
        }
        @Override
        public int getRowCount() {
            return this.data.size();
        }
        @Override
        public int getColumnCount() {
            return data.get(0).getClass().getDeclaredFields().length;
        }
        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            try {
                Method[] methods = data.get(rowIndex).getClass().getMethods();
                return methods[columnIndex].invoke(data.get(rowIndex), null);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            throw new UnsupportedOperationException("Not supported yet.");
        }
        @Override
        public void setValueAt(Object value, int rowIndex, int columnIndex) {
            Field[] fields = data.get(rowIndex).getClass().getDeclaredFields();
            try {
                fields[columnIndex].setAccessible(true);
                fields[columnIndex].set(data.get(rowIndex), value);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            fireTableCellUpdated(rowIndex, columnIndex);
        }
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            Field[] fields = data.get(0).getClass().getDeclaredFields();
            return fields[columnIndex].getType();
        }
        @Override
        public String getColumnName(int column) {
            Field[] fields = data.get(0).getClass().getDeclaredFields();
            return fields[column].getName();
        }
        @Override
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return true;
        }
    }

    public static class User
    {

        private String firstName;
        private String secondtName;

        public User(String firstName, String secondtName)
        {
            this.firstName = firstName;
            this.secondtName = secondtName;
        }

        public String getfirstName() { return this.firstName; }
        public String getsecondtName() { return this.secondtName; }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }
        public void setSecondtName(String secondtName) {
            this.secondtName = secondtName;
        }

    }
}
