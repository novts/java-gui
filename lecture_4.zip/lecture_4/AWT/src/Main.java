import java.awt.*;
import java.awt.event.*;

public class Main {

    public static void main(String[] args) {
        Frame mainFrame = new Frame("Java AWT Examples");
        mainFrame.setSize(400,500);
        mainFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
                System.exit(0);
            }
        });
       /* FlowLayout layout = new FlowLayout();
        layout.setHgap(10);
        layout.setVgap(10);
        mainFrame.setLayout(layout);

        Panel panel1=new Panel();
        panel1.setLayout(layout);
        panel1.setPreferredSize(new Dimension(200,200));
        panel1.setBackground(Color.gray);
        Button b1=new Button("Button 1");
        b1.setBackground(Color.yellow);
        panel1.add(b1);

        Panel panel2=new Panel();
        panel2.setLayout(layout);
        panel2.setPreferredSize(new Dimension(200,200));
        panel2.setBackground(Color.pink);
        Button b2=new Button("Button 2");
        b2.setBackground(Color.green);
        panel2.add(b2);

        mainFrame.add(panel1);
        mainFrame.add(panel2);


        FlowLayout layout = new FlowLayout(FlowLayout.RIGHT);
        mainFrame.setLayout(layout);
       for(int i=1; i<6; i++) {
            mainFrame.add(new Button("Button " + i));
        }

        mainFrame.add(new Button("Button 1"), BorderLayout.NORTH);
        mainFrame.add(new Button("Button 2"), BorderLayout.SOUTH);
        mainFrame.add(new Button("Button 3"), BorderLayout.EAST);
        mainFrame.add(new Button("Button 4"), BorderLayout.WEST);
        mainFrame.add(new Button("Button 5"), BorderLayout.CENTER);

        CardLayout layout = new CardLayout();
        mainFrame.setLayout(layout);
        Panel panel = new Panel();
        panel.setLayout(new GridLayout(2,3)); // 2 rows, 3 cols
        panel.add(new Button("Button One"));
        panel.add(new Button("Button Two"));
        panel.add(new Button("Button Three"));
        panel.add(new Button("Button Four"));
        panel.add(new Button("Button Five"));
        panel.add(new Button("Button Six"));
        mainFrame.add("Main Panel",panel);

        Panel panel = new Panel();
        GridBagLayout layout = new GridBagLayout();
        panel.setLayout(layout);
        GridBagConstraints constraints = new GridBagConstraints();
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new Button("Button 1"),gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(new Button("Button 2"),gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.ipady = 20;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new Button("Button 3"),gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(new Button("Button 4"),gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 2;
        panel.add(new Button("Button 5"),gbc);

        mainFrame.add(panel);

        mainFrame.setLayout(null);
        Button b1 = new Button("Button 1");
        Button b2 = new Button("Button 2");
        b1.setBounds(10, 100, 150, 50);
        b2.setBounds(250, 100, 75, 50);
        mainFrame.add(b1);
        mainFrame.add(b2);




        final Dialog d = new Dialog(mainFrame , "Dialog Example", true);
        d.setLayout( new FlowLayout() );
        Button bD = new Button ("OK");
        bD.addActionListener ( new ActionListener()
        {
            public void actionPerformed( ActionEvent e )
            {
                d.setVisible(false);
            }
        });
        d.add(bD);
        d.setSize(300,300);

        Button b = new Button("Button");
        b.addActionListener(new ActionListener()
        {
            public void actionPerformed( ActionEvent e )
            {
                d.setVisible(true);
            }
        });

        mainFrame.setLayout( new FlowLayout() );
        mainFrame.add(b);*/


         class Scroll extends Panel implements AdjustmentListener
        {
           private Scrollbar hsb, vsb;
           private  int hr, vr;

            private Dimension preferredDimension;
            private int width, height;

            public Scroll (int w, int h)
            {
                this.setLayout(new FlowLayout(FlowLayout.RIGHT));
                width=w;
                height=h;
                preferredDimension = new Dimension(w, h);
                setSize(preferredDimension);

                hsb=new Scrollbar (Scrollbar.HORIZONTAL);
                hsb.setMaximum (100);
                hsb.setPreferredSize(new Dimension(width,10));
                hsb.setMinimum (10);
                vsb=new Scrollbar (Scrollbar.VERTICAL);
                vsb.setMaximum (100);
                vsb.setPreferredSize(new Dimension(10,height));
                vsb.setMinimum (10);
                add (hsb);
                add (vsb);
                hsb.addAdjustmentListener (this);
                vsb.addAdjustmentListener (this);
                hr=hsb.getValue();
                vr=vsb.getValue();
                setVisible (true);

            }
            public void adjustmentValueChanged (AdjustmentEvent ae)
            {
                hr=hsb.getValue();
                vr=vsb.getValue();
                repaint ();
            }

            public Dimension getPreferredSize() {
                return(preferredDimension);
            }
            public Dimension getMinimumSize() {
                return(preferredDimension);
            }

            public void setCenter(int x, int y) {
                setLocation(x - width/2, y - height/2);
            }

            public void paint (Graphics g)
            {
                g.setColor (Color.BLUE);
                g.fillOval (10, 20, width*hr/100, height*vr/100);

            }
        }


        mainFrame.setLayout( new FlowLayout() );
        Scroll scroll = new Scroll (300,300);
        scroll.setCenter(100,100);
        mainFrame.add(scroll);
        mainFrame.pack();

        mainFrame.setVisible(true);

    }
}
