package com.novts;

import java.io.Serializable;
import java.beans.*;
public class Data implements Serializable{
	private String data;
private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);	
public void addPropertyChangeListener(String propertyName,
			PropertyChangeListener listener) {		propertyChangeSupport.addPropertyChangeListener(propertyName, listener);}
public void removePropertyChangeListener(PropertyChangeListener listener) {
	propertyChangeSupport.removePropertyChangeListener(listener);
	}	
	public String getData() {
		return data;
	}
	public void setData(String data) {
	propertyChangeSupport.firePropertyChange("data", this.data,	
			this.data = data);
	}}


