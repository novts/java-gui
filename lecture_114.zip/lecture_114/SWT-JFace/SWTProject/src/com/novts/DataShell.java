package com.novts;

import org.eclipse.core.databinding.DataBindingContext;
import org.eclipse.core.databinding.beans.BeansObservables;
import org.eclipse.core.databinding.beans.PojoObservables;
import org.eclipse.core.databinding.observable.Realm;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.jface.databinding.swt.WidgetProperties;

public class DataShell extends Shell {

	private DataBindingContext m_bindingContext;
	private com.novts.Data data = new com.novts.Data();
	private Text dataText;
	private Label lblNewLabel;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String args[]) {
		Display display = new Display();
		Realm.runWithDefault(SWTObservables.getRealm(display), new Runnable() {
			public void run() {
				try {
					Display display = Display.getDefault();
					DataShell shell = new DataShell(display, SWT.SHELL_TRIM);
					shell.open();
					shell.layout();
					while (!shell.isDisposed()) {
						if (!display.readAndDispatch()) {
							display.sleep();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the shell.
	 * @param display
	 * @param style
	 */
	public DataShell(Display display, int style) {
		super(display, style);
		createContents();
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		setText("SWT Application");
		setSize(450, 300);
		setLayout(new GridLayout(2, false));

		new Label(this, SWT.NONE).setText("Data:");

		dataText = new Text(this, SWT.BORDER | SWT.SINGLE);
		dataText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
		new Label(this, SWT.NONE);
		new Label(this, SWT.NONE);
		new Label(this, SWT.NONE);
		new Label(this, SWT.NONE);
		new Label(this, SWT.NONE);
		
		Button btnNewButton = new Button(this, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				data.setData("Hello");
				setData(data);

			}
		});
		btnNewButton.setText("New Button");
		new Label(this, SWT.NONE);
		new Label(this, SWT.NONE);
		new Label(this, SWT.NONE);
		
		lblNewLabel = new Label(this, SWT.NONE);
		lblNewLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		lblNewLabel.setText("New Label");

		if (data != null) {
			m_bindingContext = initDataBindings();
		}
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	public com.novts.Data getData() {
		return data;
	}

	public void setData(com.novts.Data newData) {
		setData(newData, true);
	}

	public void setData(com.novts.Data newData, boolean update) {
		data = newData;
		if (update) {
			if (m_bindingContext != null) {
				m_bindingContext.dispose();
				m_bindingContext = null;
			}
			if (data != null) {
				m_bindingContext = initDataBindings();
			}
		}
	}

	protected DataBindingContext initDataBindings() {
		DataBindingContext bindingContext = new DataBindingContext();
		//
		IObservableValue dataObserveWidget = SWTObservables.observeText(dataText, SWT.Modify);
		IObservableValue dataObserveValue = BeansObservables.observeValue(data, "data");
		bindingContext.bindValue(dataObserveWidget, dataObserveValue, null, null);
		//
		IObservableValue observeTextLblNewLabelObserveWidget = WidgetProperties.text().observe(lblNewLabel);
		IObservableValue observeTextDataTextObserveWidget = WidgetProperties.text(SWT.Modify).observe(dataText);
		bindingContext.bindValue(observeTextLblNewLabelObserveWidget, observeTextDataTextObserveWidget, null, null);
		//
		return bindingContext;
	}
}
