import javax.swing.*;

import java.awt.*;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Internal Frames Example");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        JDesktopPane desktop = new JDesktopPane();
        desktop.setBackground(Color.LIGHT_GRAY);
        frame.add(desktop, BorderLayout.CENTER);

        for(int i=0; i<5; i++) {
            JInternalFrame iframe = new JInternalFrame(("Internal Frame " + i),
                    true, true, true, true);
            iframe.setLocation(i*50+10, i*50+10);
            iframe.setSize(200, 150);
            iframe.setBackground(Color.WHITE);
            desktop.add(iframe);
            iframe.moveToFront();
            iframe.setVisible(true);
        }

        frame.setSize(500,500);
        frame.setVisible(true);
    }
}
