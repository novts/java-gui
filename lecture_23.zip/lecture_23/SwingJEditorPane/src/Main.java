import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class Main {

    public static void main(String[] args) {
       final JFrame myFrame = new JFrame("JEditorPane HTML");
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setSize(600,600);
       final JEditorPane myPane = new JEditorPane();
        myPane.setContentType("text/html");
        myFrame.setContentPane(myPane);

        String htmlContent = "<html><p><img src=" + ClassLoader.getSystemResource("img.jpg").toString() + " width=200></p></html>";
        myPane.setText(htmlContent);

        System.out.println(ClassLoader.getSystemResource("img.jpg").toString());

        JMenuBar myBar = new JMenuBar();
        JMenu myMenu = new JMenu("File");
        JMenuItem myItem = new JMenuItem("Open");
        myItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser  fileDialog = new JFileChooser();
                int returnVal = fileDialog.showOpenDialog(myFrame);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    java.io.File file = fileDialog.getSelectedFile();
                    try {
                        String text = new String(Files.readAllBytes(file.toPath()));
                        myPane.setText(text);
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });
        myMenu.add(myItem);

        myItem = new JMenuItem("Save");
        myItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setCurrentDirectory(new File("/Users/user"));
                int retrival = chooser.showSaveDialog(null);
                if (retrival == JFileChooser.APPROVE_OPTION) {
                    try {
                        Files.write(chooser.getSelectedFile().toPath(), myPane.getText().getBytes());
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });
        myMenu.add(myItem);
        myBar.add(myMenu);

        myMenu = new JMenu("View");
        ButtonGroup myGroup = new ButtonGroup();
        myItem = new JRadioButtonMenuItem("HTML");
        myItem.setSelected(true);
        myItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String   text = myPane.getText();
                myPane.setContentType("text/html");
                myPane.setText(text);
            }
        });
        myMenu.add(myItem);
        myGroup.add(myItem);

        myItem = new JRadioButtonMenuItem("Plain");
        myItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               String text = myPane.getText();
                myPane.setContentType("text/plain");
                myPane.setText(text);
            }
        });
        myMenu.add(myItem);
        myGroup.add(myItem);

        myBar.add(myMenu);

        myFrame.setJMenuBar(myBar);
        myFrame.setVisible(true);
    }
}
