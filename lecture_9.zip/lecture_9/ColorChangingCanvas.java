import java.awt.*;
import java.awt.event.*;



public class ColorChangingCanvas extends Canvas {
  public ColorChangingCanvas(int width, int height) {
    setSize(width, height);
    setRandomBackground();
    addMouseListener(new ColorChanger());
  }

  private void setRandomBackground() {
    Color bgColor =
          new Color((float)Math.random(),
                    (float)Math.random(),
                    (float)Math.random());
    setBackground(bgColor);
  }

  private class ColorChanger extends MouseAdapter {
    @Override
    public void mousePressed(MouseEvent e) {
      setRandomBackground();
    }
  }
}