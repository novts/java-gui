import java.awt.*;



public class CloseableFrame extends Frame {
  public CloseableFrame(String title) {
    super(title);
    addWindowListener(new ExitListener());
  }
}