import java.awt.*;
import java.awt.event.*;

public class ThreeButtons extends Frame implements ActionListener {
    private Button b1, b2, b3;

    public ThreeButtons() {
        this.addWindowListener(new ExitListener());
        setLayout(new FlowLayout());
        b1 = new Button("Red");
        b2 = new Button("Green");
        b3 = new Button("Blue");
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        add(b1);
        add(b2);
        add(b3);
        pack();
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            setBackground(Color.RED);
        } else if (e.getSource() == b2) {
            setBackground(Color.GREEN);
        } else {
            setBackground(Color.BLUE);
        }
    }

    public static void main(String[] args) {
        new ThreeButtons();
    }
