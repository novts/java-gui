package sample;

import javafx.scene.control.Label;
import javafx.scene.control.Skin;

public class MyCustomControl extends Label {
    public MyCustomControl() {
           //getStyleClass().add("custom-control");
           setSkin(new MyCustomControlSkin(this));

    }

    @Override
    public String getUserAgentStylesheet() {
        return MyCustomControl.class.getResource("customcontrol.css").toExternalForm();
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new MyCustomControlSkin(this);
    }

}