package sample;

import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.*;
import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.geometry.*;
import javafx.geometry.Insets;
import javafx.print.PrinterJob;
import javafx.scene.*;
import javafx.scene.Cursor;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.*;
import javafx.scene.effect.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.*;
import javafx.scene.text.Font;
import javafx.scene.transform.Rotate;
import javafx.scene.web.HTMLEditor;
import javafx.scene.web.WebView;
import javafx.stage.*;
import javafx.util.Callback;
import javafx.util.Duration;
import javafx.util.StringConverter;
import javafx.util.converter.DateTimeStringConverter;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
     //   Group root = new Group();

      //  HBox root = new HBox();
      //  root.setSpacing(50);

        Scene scene = new Scene(root, 500, 500, Color.BEIGE);

     //   MyCustomControl custom = new MyCustomControl();
     //   root.getChildren().add(custom);

        String pathS = this.getClass().getResource("stylesheet.css").toString();
     //   scene.getStylesheets().addAll(pathS);
    //    scene.setUserAgentStylesheet(pathS);

        Button btn = new Button("Button");
        btn.getStyleClass().add("custom-button");
        btn.setId("font-button");
        btn.setStyle("-fx-font:  bold italic 10pt Helvetica;");

        TextField field=new TextField();

        field.setLayoutX(50);
        field.setLayoutY(50);

    //    btn.textProperty().bind(field.textProperty());

        btn.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                btn.textProperty().set("Hello");
            }});
        btn.textProperty().bindBidirectional(field.textProperty());


     //   root.getChildren().add(btn);
     //   root.getChildren().add(field);

        CheckBox ckb = new CheckBox("Check it!");
        ckb.setSelected(true);
        ckb.setIndeterminate(true);
        ckb.setAllowIndeterminate(true);

        ckb.selectedProperty().addListener(
                (ObservableValue<? extends Boolean> ov,
                 Boolean old_val, Boolean new_val) -> {
                    if(new_val==true){
                        ckb.setCursor(Cursor.CROSSHAIR);
                    }else{
                        ckb.setCursor(Cursor.DEFAULT);
                    }
                });

        ckb.setLayoutX(50);
        ckb.setLayoutY(50);

      //  root.getChildren().add(ckb);

        Button  btnD = new Button("Click me!");

        final EventDispatchChain ec = btnD.buildEventDispatchChain(new com.sun.javafx.event.EventDispatchChainImpl()
                .append(new EventDispatcher(){

                    public Event dispatchEvent(Event event, EventDispatchChain edc) {

                        if(event.getEventType().getName().equals("MOUSE_CLICKED")){
                            System.out.println("Hello World");
                            edc.dispatchEvent(event);
                        }
                        return event;
                    }
                }));

        scene.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                ec.dispatchEvent(event);
            }});

       // root.getChildren().add(btnD);

        Hyperlink hlink = new Hyperlink("This is Hyperlink");

        hlink.setStyle("-fx-font:  bold italic 14pt Georgia; -fx-border-width: 0");
        hlink.setAlignment(Pos.CENTER);
        hlink.setTextAlignment(TextAlignment.CENTER);
        hlink.setUnderline(true);
        hlink.setTextFill(Color.BLACK);

        hlink.setOnMouseEntered((MouseEvent event) -> {
                if(!hlink.isVisited()){
                   hlink.setTextFill(Color.BLUE);
                   hlink.setStyle("-fx-font:  bold italic 16pt Georgia;-fx-border-width: 0");
                    }
            });
        hlink.setOnMousePressed((MouseEvent event)-> {
                if(!hlink.isVisited()){
                   hlink.setTextFill(Color.RED);
                   hlink.setStyle("-fx-font:  bold italic 16pt Georgia; -fx-border-style: solid");
                    }
            });
        hlink.setOnMouseExited((MouseEvent event)-> {
                if(!hlink.isVisited()){
                    hlink.setTextFill(Color.BLACK);
                    hlink.setStyle("-fx-font:  bold italic 14pt Georgia;-fx-border-width: 0");
                }
            });


        hlink.setOnAction((ActionEvent e) -> {
            System.out.println("This link is clicked");
            hlink.setVisited(false);
        });


        //root.getChildren().add(hlink);

        final ToggleGroup group = new ToggleGroup();

        ToggleButton tb1 = new ToggleButton("Button 1");
        tb1.setToggleGroup(group);
       // tb1.setSelected(true);

        ToggleButton tb2 = new ToggleButton("Button 2");
        tb2.setToggleGroup(group);

        tb1.setUserData("Button 1");
        tb2.setUserData("Button 2");

        group.selectedToggleProperty().addListener(
                (ObservableValue<? extends Toggle> ov,
                Toggle toggle, Toggle new_toggle) -> {

                    System.out.println(new_toggle.getUserData().toString());

        });

        tb1.selectedProperty().addListener((ObservableValue<? extends Boolean> ov, Boolean old_val, Boolean new_val) -> {
                if (new_val.equals(Boolean.TRUE))
                    scene.setFill(Color.web("#fff8dc"));
               });


    //    root.getChildren().addAll(tb1, tb2);

        ObservableList<String> country = FXCollections.observableArrayList(
                "Россия","США","Великобритания");

        ChoiceBox<String> choice = new ChoiceBox<String>(country);

        choice.setTooltip(new Tooltip("Выберите страну"));

        choice.getSelectionModel().selectFirst();

        choice.getSelectionModel().selectedItemProperty().addListener(
                (ObservableValue<? extends String> ov, String old_val, String new_val) -> {
               System.out.println(new_val);
        });

      //  root.getChildren().add(choice);

        final TextField name = new TextField();
        name.setPromptText("Enter your first name.");
        name.setFocusTraversable(false);
     //   name.setEditable(false);
        name.setOnAction((ActionEvent e) -> {
            if ((name.getText() != null && !name.getText().isEmpty())){
                System.out.println(name.getText());
            }
        });

      // root.getChildren().add(name);

        final PasswordField password = new PasswordField();
        password.setFocusTraversable(false);
        password.setPromptText("Пароль");
        password.setOnAction((ActionEvent e)-> {
                System.out.println( password.getText());
            });


      //  root.getChildren().add(password);

        Button btnS = new Button("Button");
        btnS.setStyle("-fx-font: bold italic 14pt Georgia;-fx-text-fill: white;-fx-background-color: #a0522d;-fx-border-width: 3px; -fx-border-color:#f4a460 #800000 #800000 #f4a460;" );
        btnS.setPrefSize(300,150);

        ScrollPane sp=new ScrollPane();
        sp.setLayoutX(10);
        sp.setLayoutY(10);
        sp.setPrefSize(150, 100);
        sp.setContent(btnS);
        sp.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        sp.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
       // sp.setFitToWidth(true);
        //sp.setFitToHeight(true);
        sp.setPannable(true);
        sp.setPrefViewportHeight(300);
        sp.setPrefViewportWidth(300);

       // root.getChildren().add(sp);

        ListView<String> list = new ListView<>();
        ObservableList<String> items =FXCollections.observableArrayList (
                "Single", "Double", "Suite", "Family App");
        list.setItems(items);

        list.setLayoutX(10);
        list.setLayoutY(10);

        list.setPrefSize(300, 170);

     //   list.setOrientation(Orientation.HORIZONTAL);

      /*  list.setCellFactory((ListView<String> p) -> {
                final Button btnL = new Button();
                btnL.setStyle("-fx-background-color:#66ccff;");
                btnL.setPrefSize(130, 50);
                btnL.setWrapText(true);
                final ListCell<String> cell = new ListCell<String>(){
                    @Override public void updateItem(String item,
                                                     boolean empty) {
                        super.updateItem(item, empty);
                        if (item != null) {
                            btnL.setText(item);
                            this.setGraphic(btnL);
                        } }};
                return cell;
             });

        list.setCellFactory(CheckBoxListCell.forListView((String item) ->{
            return new ReadOnlyBooleanWrapper(true);
            }
        ));
        */

        list.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        list.getSelectionModel().selectedItemProperty().addListener(
                (ObservableValue<? extends String> ov, String old_val, String new_val)-> {
                 //   System.out.println(new_val);
                    System.out.println(list.getSelectionModel().getSelectedItem());
                 });
        list.setEditable(true);
        list.setCellFactory(TextFieldListCell.forListView());


        //root.getChildren().add(list);

        ObservableList<Hotel> hotels =
                FXCollections.observableArrayList(
                        new Hotel("Amara Dolce Vita","Kemer","HV1",4.5),
                        new Hotel("Club Boran Mare Beach","Kemer","HV1",4.7),
                        new Hotel("Delphin Botanik World of Paradise","Alanya","5*",4.4),
                        new Hotel("Kamelya World Hotel Fulya","Side","5*",4.8),
                        new Hotel("Delphin Deluxe Resort","Alanya","5*",4.7));

        TableView<Hotel> table = new TableView();

        table.setLayoutX(10);
        table.setLayoutY(50);

        TableColumn nameCol = new TableColumn("Отель");
        nameCol.setCellValueFactory(
                new PropertyValueFactory<Hotel,String>("name")
        );

        TableColumn resortCol = new TableColumn("Курорт");
        resortCol.setCellValueFactory(
                new PropertyValueFactory<Hotel,String>("resort")
        );

        TableColumn categoryCol = new TableColumn("Категория");
        categoryCol.setCellValueFactory(
                new PropertyValueFactory<Hotel,String>("category")
        );

        TableColumn rateCol = new TableColumn("Рейтинг");
        rateCol.setCellValueFactory(
                new PropertyValueFactory<Hotel, Double>("rate")
        );

        nameCol.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Hotel, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Hotel, String> p) {
                return p.getValue().nameProperty();
            }
        });

        table.setItems(hotels);

        table.getColumns().addAll(nameCol, resortCol, categoryCol, rateCol);

        table.setTableMenuButtonVisible(true);
      //  table.setStyle("-fx-font: 14pt Arial;");
        table.setPrefWidth(500);
        table.setPrefHeight(200);

        table.setCursor(Cursor.TEXT);
        table.setTooltip(new Tooltip("Популярные отели Турции"));

        TableColumn firstNameCol = new TableColumn("First");
        TableColumn secondNameCol = new TableColumn("Secondary");

       // nameCol.getColumns().addAll(firstNameCol, secondNameCol);

        table.setPlaceholder(new Label("No Data"));

        table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        table.getSelectionModel().selectedItemProperty().addListener(
                (ObservableValue<? extends Hotel> observable, Hotel oldValue, Hotel newValue)-> {
                  //  System.out.println(newValue.nameProperty().getValue());
                    System.out.println(table.getSelectionModel().getSelectedItem().nameProperty().getValue());
                   // hotels.add(new Hotel("Name","Resort","Category",5.0));
        });


     //   table.getSortOrder().addAll(resortCol,nameCol);
        nameCol.setSortType(TableColumn.SortType.ASCENDING);
        resortCol.setSortType(TableColumn.SortType.DESCENDING);


        table.setEditable(true);
        nameCol.setCellFactory(TextFieldTableCell.<Hotel>forTableColumn());

        nameCol.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Hotel,String>>(){

            @Override
            public void handle(TableColumn.CellEditEvent<Hotel, String> event) {

                System.out.println(event.getNewValue());
                ((Hotel)event.getTableView().getItems().get(event.getTablePosition().getRow())).setName(event.getNewValue());
                System.out.println(((Hotel) event.getTableView().getItems().get(event.getTablePosition().getRow())).nameProperty().getValue());

            }
        });

      //  root.getChildren().add(table);


        TreeItem<String> rootItem = new TreeItem<> ("Популярные отели Турции");
        rootItem.setExpanded(true);

        for(Hotel hotel:hotels){
            TreeItem<String> item = new TreeItem<> (hotel.getName());
            rootItem.getChildren().add(item);
            TreeItem<String> leafC = new TreeItem<> (hotel.getCategory());
            item.getChildren().add(leafC);
            TreeItem<String> leafR = new TreeItem<> (hotel.getResort());
            item.getChildren().add(leafR);
            TreeItem<String> leafT = new TreeItem<> (hotel.getRate().toString());
            item.getChildren().add(leafT);
        }

        TreeView<String> tree = new TreeView (rootItem);

      //  tree.setStyle("-fx-border-width:3pt;-fx-border-color:#f0e68c;-fx-font: 14pt Georgia;");
      //  tree.setPrefSize(300, 200);

        tree.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        tree.getSelectionModel().selectedItemProperty().addListener(
                (ObservableValue<? extends TreeItem<String>> ov, TreeItem<String> old_val, TreeItem<String> new_val)-> {

                System.out.println(new_val.getValue());

                 });

        tree.setEditable(true);
        tree.setCellFactory(TextFieldTreeCell.forTreeView());
        tree.setOnEditCommit(new EventHandler<TreeView.EditEvent<String>>(){

            @Override
            public void handle(TreeView.EditEvent<String> event) {
                System.out.println(event.getNewValue());
            }
        });


      //  root.getChildren().add(tree);

    //    TreeItem<Hotel> rootH = new TreeItem (hotels.get(0));
    //    TreeView<Hotel> treeH = new TreeView (rootH);


        TreeItem<Hotel> rootH = new TreeItem<>(new Hotel("Популярные отели Турции", "","", 5.0));
        rootH.setExpanded(true);

        TreeItem<Hotel> leaf = new TreeItem<>(new Hotel("Hotels", "","", 5.0));
        rootH.getChildren().add(leaf);

        hotels.stream().forEach((hotel) -> {
           leaf.getChildren().add(new TreeItem<>(hotel));
        });

        TreeTableColumn<Hotel, String> nameColumn = new TreeTableColumn<>("Hotel");
        nameColumn.setCellValueFactory(
                new TreeItemPropertyValueFactory<Hotel,String>("name")
        );
        TreeTableColumn<Hotel, String> resortColumn = new TreeTableColumn<>("Resort");
        resortColumn.setCellValueFactory(
                new TreeItemPropertyValueFactory<Hotel,String>("resort")
        );
        TreeTableColumn<Hotel, String> categoryColumn = new TreeTableColumn<>("Category");
        categoryColumn.setCellValueFactory(
                new TreeItemPropertyValueFactory<Hotel,String>("category")
        );
        TreeTableColumn<Hotel, Double> rateColumn = new TreeTableColumn<>("Rate");
        rateColumn.setCellValueFactory(
                new TreeItemPropertyValueFactory<Hotel,Double>("rate")
        );

        TreeTableView<Hotel> treeTableView = new TreeTableView(rootH);
        treeTableView.getColumns().setAll(nameColumn, resortColumn, categoryColumn, rateColumn);

        treeTableView.setTableMenuButtonVisible(true);
        //  treeTableView.setStyle("-fx-font: 14pt Arial;");
        treeTableView.setPrefSize(500, 400);

        treeTableView.setCursor(Cursor.TEXT);
        treeTableView.setTooltip(new Tooltip("Популярные отели Турции"));

        TreeTableColumn firstNameColumn = new TreeTableColumn("First");
        TreeTableColumn secondNameColumn = new TreeTableColumn("Secondary");

       // resortColumn.getColumns().addAll(firstNameColumn, secondNameColumn);

        treeTableView.setPlaceholder(new Label("No Data"));

        treeTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        treeTableView.getSelectionModel().selectedItemProperty().addListener(
                (ObservableValue<? extends TreeItem<Hotel>> observable, TreeItem<Hotel> oldValue, TreeItem<Hotel> newValue)-> {
                    System.out.println(((Hotel)newValue.getValue()).getCategory());
        });

        treeTableView.setEditable(true);
        nameColumn.setCellFactory(TextFieldTreeTableCell.<Hotel>forTreeTableColumn());

        nameColumn.setOnEditCommit(new EventHandler<TreeTableColumn.CellEditEvent<Hotel,String>>(){

            @Override
            public void handle(TreeTableColumn.CellEditEvent<Hotel, String> event) {

                System.out.println(event.getNewValue());
                ((Hotel)event.getRowValue().getValue()).setName(event.getNewValue());
            }
        });


     //   root.getChildren().add(treeTableView);

        ObservableList<String> options =
                FXCollections.observableArrayList(
                        "Option 1",
                        "Option 2",
                        "Option 3",
                        "Option 4",
                        "Option 5",
                        "Option 6",
                        "Option 7"
                );
        final ComboBox comboBox = new ComboBox(options);

        comboBox.getSelectionModel().selectFirst();
        comboBox.getSelectionModel().selectedItemProperty().addListener(
                (ObservableValue observable, Object oldValue, Object newValue)-> {
                System.out.println(newValue);
        });
        comboBox.setValue("Option 0");
        comboBox.setVisibleRowCount(3);
        comboBox.setPlaceholder(new Label("No Data"));

      //  comboBox.setEditable(true);
        comboBox.setPromptText("options");
        comboBox.setFocusTraversable(false);
        comboBox.setOnAction((Event ev) -> {
            if(comboBox.getSelectionModel().getSelectedIndex()==-1) {
                options.add(comboBox.getSelectionModel().getSelectedItem().toString());
            }else{
                int i = comboBox.getSelectionModel().getSelectedIndex();
                options.set(i, comboBox.getSelectionModel().getSelectedItem().toString());
            }
        });

        comboBox.setCellFactory(CheckBoxListCell.forListView(new Callback<String, ObservableValue<Boolean>>() {
            @Override
            public ObservableValue<Boolean> call(String item) {
                BooleanProperty observable = new SimpleBooleanProperty();
                observable.setValue(true);
                return observable;
            }
        }));

      //  root.getChildren().add(comboBox);

        Separator sepH=new Separator();
        sepH.setLayoutX(10);
        sepH.setLayoutY(160);
        sepH.setPrefWidth(400);
        sepH.setPrefHeight(5);
        sepH.setOrientation(Orientation.HORIZONTAL);
        sepH.setValignment(VPos.BOTTOM);
        sepH.setStyle("-fx-background-color:blue;");

        Separator sepV=new Separator();
        sepV.setLayoutX(10);
        sepV.setLayoutY(10);
        sepV.setPrefHeight(300);
        sepV.setOrientation(Orientation.VERTICAL);
        sepV.setHalignment(HPos.RIGHT);
        sepV.setStyle("-fx-background-color:blue;");

       // root.getChildren().addAll(sepV, sepH);

        Slider slider=new Slider();
        slider.setLayoutX(20);
        slider.setLayoutY(20);
        slider.setCursor(Cursor.CROSSHAIR);
        slider.setPrefHeight(300);
        slider.setBlockIncrement(1);
        slider.setMajorTickUnit(1);
        slider.setMax(10);
        slider.setMin(0);
        slider.setMinorTickCount(2);
        slider.setOrientation(Orientation.VERTICAL);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setSnapToTicks(true);
        slider.valueProperty().addListener(
                (ObservableValue<? extends Number> ov,Number old_val, Number new_val)-> {
                System.out.println(new_val.intValue());
             });

       // root.getChildren().add(slider);

        ProgressBar pb =new ProgressBar();
        pb.setLayoutX(20);
        pb.setLayoutY(50);
        pb.setCursor(Cursor.TEXT);
        DropShadow effect=new DropShadow();
        effect.setOffsetX(8);
        effect.setOffsetY(8);
        pb.setEffect(effect);
        pb.setTooltip(new Tooltip("Индикатор выполнения задачи"));
        pb.setPrefSize(200,30);

        ProgressIndicator pI=new ProgressIndicator();
        pI.setLayoutX(250);
        pI.setLayoutY(50);
        pI.setCursor(Cursor.TEXT);
        pI.setStyle("-fx-font:bold 14pt Arial;");
        pI.setTooltip(new Tooltip("Индикатор выполнения задачи"));
        pI.setPrefSize(70,70);


        final DoubleProperty progress=new SimpleDoubleProperty(-1.0);
        pb.progressProperty().bind(progress);
        pI.progressProperty().bind(progress);

        Button btnI=new Button("Start");
        btnI.setLayoutX(20);
        btnI.setLayoutY(100);
        btnI.setStyle("-fx-font: 16pt Arial;");
        btnI.setOnAction((ActionEvent e)->{
                if(progress.getValue()<=1.0)
                    progress.setValue(progress.getValue()+0.2);
            });

        Button btnR=new Button("Reset");
        btnR.setLayoutX(100);
        btnR.setLayoutY(100);
        btnR.setStyle("-fx-font: 16pt Arial;");
        btnR.setOnAction((ActionEvent e)-> {
                progress.setValue(0.0);
            });

      //  root.getChildren().addAll(pI, pb, btnI, btnR);

        String html = "<html><body bgcolor=#A0BEC4></body></html>";
        WebView webV=new WebView();
        webV.setPrefSize(300, 200);
        webV.setCursor(Cursor.TEXT);
        webV.getEngine().loadContent(html);

        HTMLEditor editor=new HTMLEditor();
        editor.setPrefSize(500, 300);
        editor.setCursor(Cursor.TEXT);
        editor.setHtmlText(html);

        Label lhtml = new Label();
        lhtml.setWrapText(true);
        lhtml.setPrefWidth(600);

        Button btnSub = new Button();
        btnSub.setText("Submit");
        btnSub.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                webV.getEngine().loadContent(editor.getHtmlText());
                lhtml.setText(editor.getHtmlText());
            }});

        VBox vbox=new VBox();
        vbox.setLayoutX(10);
        vbox.setLayoutY(10);
        vbox.setSpacing(20);

        vbox.getChildren().addAll(webV, editor, btnSub, lhtml);
     //   root.getChildren().addAll(vbox);

        TitledPane tp =new TitledPane();
        tp.setLayoutX(10);
        tp.setLayoutY(10);
        tp.setCursor(Cursor.CROSSHAIR);
        tp.setStyle("-fx-border-width:4pt;-fx-border-color:olive;");
       // tp.setPrefWidth(500);
        tp.setTooltip(new Tooltip("Panel"));
        //tp.setAnimated(false);
        //tp.setCollapsible(false);

        Label labelT = new Label("Title");
        labelT.setCursor(Cursor.CLOSED_HAND);
        labelT.setPrefSize(300,30);
        labelT.setStyle("-fx-font: bold italic 16pt Georgia;-fx-text-fill:black;-fx-background-color:#e6e6fa;");
        labelT.setAlignment(Pos.CENTER);
        tp.setGraphic(labelT);

        Label labelC = new Label("Content");
        labelC.setPrefSize(300,300);
        labelC.setAlignment(Pos.CENTER);

        tp.setContent(labelC);
       // root.getChildren().add(tp);

        String[] imageNames = new String[]{"Apples", "Flowers", "Leaves"};
        TitledPane[] tps = new TitledPane[imageNames.length];

        Accordion accordion = new Accordion ();
        for (int i = 0; i < imageNames.length; i++) {

            tps[i] = new TitledPane(imageNames[i], new Label(imageNames[i]));
        }
        accordion.getPanes().addAll(tps);

        accordion.setPrefSize(200,200);
        accordion.setExpandedPane(tps[0]);

       // root.getChildren().add(accordion);

        MenuBar menuBar = new MenuBar();
        menuBar.setLayoutX(10);
        menuBar.setLayoutY(10);
        menuBar.setBlendMode(BlendMode.HARD_LIGHT);
        menuBar.setCursor(Cursor.CLOSED_HAND);
        effect=new DropShadow();
        effect.setOffsetX(5);
        effect.setOffsetY(5);
        menuBar.setEffect(effect);
        menuBar.setStyle("-fx-base:skyblue;-fx-border-width:4pt;-fx-border-color:navy;-fx-font:bold 16pt Georgia;");
        menuBar.setPrefSize(250, 50);

        Menu menuF = new Menu("File");
        MenuItem menuItemP = new MenuItem("Print");
        menuItemP.setStyle("-fx-text-fill:navy;-fx-font:bold italic 14pt Georgia;");
        menuItemP.setAccelerator(KeyCombination.keyCombination("Ctrl+P"));
        menuItemP.setOnAction((ActionEvent e)-> {
                System.out.println("Printing...");
             });

        SeparatorMenuItem sep=new SeparatorMenuItem();

        ToggleGroup tgroup=new ToggleGroup();

        RadioMenuItem radioItemY = new RadioMenuItem("With page number");
        radioItemY.setStyle("-fx-text-fill:navy;-fx-font:bold italic 12pt Georgia;");
        radioItemY.setToggleGroup(tgroup);
        radioItemY.setSelected(true);

        RadioMenuItem radioItemN = new RadioMenuItem("Without page number");
        radioItemN.setStyle("-fx-text-fill:navy;-fx-font:bold italic 12pt Georgia;");
        radioItemN.setToggleGroup(tgroup);

        CheckMenuItem checkMenuItem=new CheckMenuItem("Improved quality");
        checkMenuItem.setSelected(true);
        checkMenuItem.setStyle("-fx-text-fill:navy;-fx-font:bold italic 14pt Georgia;");

        menuF.getItems().addAll(menuItemP, radioItemY, radioItemN, sep, checkMenuItem);

        menuBar.getMenus().addAll(menuF);

      //  root.getChildren().add(menuBar);

        MenuButton btnM = new MenuButton("Edit");
        btnM.setLayoutX(20);
        btnM.setLayoutY(20);
        btnM.setPrefSize(200,80);
        btnM.setStyle("-fx-font: bold italic 18pt Georgia;");
        btnM.setAlignment(Pos.CENTER);
        btnM.setPopupSide(Side.RIGHT);
        MenuItem menuItemCut = new MenuItem("Cut");
        menuItemCut.setStyle("-fx-font:bold italic 14pt Times;" );
        menuItemCut.setAccelerator(KeyCombination.keyCombination("Ctrl+U"));
        menuItemCut.setOnAction((ActionEvent e)-> {
                System.out.println("Cutting...");
             });
        MenuItem menuItemCopy = new MenuItem("Copy");
        menuItemCopy.setStyle("-fx-font:bold italic 14pt Times;" );
        menuItemCopy.setAccelerator(KeyCombination.keyCombination("Ctrl+O"));
        menuItemCopy.setOnAction((ActionEvent e)-> {
                System.out.println("Copying...");
             });
        MenuItem menuItemPaste = new MenuItem("Paste");
        menuItemPaste.setStyle("-fx-font:bold italic 14pt Times;" );
        menuItemPaste.setAccelerator(KeyCombination.keyCombination("Ctrl+P"));
        menuItemPaste.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                System.out.println("Pasting...");
            } });

        btnM.getItems().addAll(menuItemCut,menuItemCopy,menuItemPaste );
       // root.getChildren().add(btnM);

        SplitMenuButton btnSp = new SplitMenuButton();
        btnSp.setText("Edit");
        btnSp.setLayoutX(20);
        btnSp.setLayoutY(20);
        btn.setBlendMode(BlendMode.HARD_LIGHT);
        btnSp.setStyle("-fx-font: bold italic 18pt Georgia;");
        btnSp.setAlignment(Pos.CENTER);
        btnSp.setPopupSide(Side.BOTTOM);
        btnSp.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                System.out.println("Button click");
            }});
        btnSp.getItems().addAll(menuItemCut,menuItemCopy,menuItemPaste );
       // root.getChildren().add(btnSp);

        ColorPicker colorPicker = new ColorPicker(Color.BLUE);
        colorPicker.setValue(Color.CORAL);

        Label labelCP = new Label("Color");

        colorPicker.setOnAction((ActionEvent t) -> {
            labelCP.setBackground(new Background(new BackgroundFill(colorPicker.getValue(), CornerRadii.EMPTY, Insets.EMPTY)));
        });

      //  root.getChildren().addAll(colorPicker, labelCP);

        DatePicker checkInDatePicker = new DatePicker();
      //  checkInDatePicker.setValue(LocalDate.of(2018, 1, 1));
        checkInDatePicker.setShowWeekNumbers(true);
        checkInDatePicker.setFocusTraversable(false);
        String pattern = "yyyy-MM-dd";
        checkInDatePicker.setConverter(new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter =
                    DateTimeFormatter.ofPattern(pattern);
            @Override
            public String toString(LocalDate object) {
                if (object != null) {
                    return dateFormatter.format(object);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });
        checkInDatePicker.setPromptText(pattern.toLowerCase());
        checkInDatePicker.setDayCellFactory(new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(DatePicker param) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);
                            setStyle("-fx-background-color: #ffc0cb;");
                    }};
            }
        });

        checkInDatePicker.setOnAction((ActionEvent t) -> {
            System.out.println(checkInDatePicker.getValue());
        });

       // root.getChildren().add(checkInDatePicker);

        FileChooser fileCh=new FileChooser();
        fileCh.setInitialDirectory(new java.io.File("C:/"));
        fileCh.setTitle("Select Image");
        fileCh.getExtensionFilters().add(new FileChooser.ExtensionFilter("jpg, png, bmp, gif", "*.jpg", "*.png", "*.bmp", "*.gif"));

        Button btnFC= new Button();
        btnFC.setLayoutX(20);
        btnFC.setLayoutY(50);
        btnFC.setText("Load Image");
        btnFC.setStyle("-fx-font: bold 16pt Georgia;" );
        btnFC.setPrefSize(250,30);
        btnFC.setOnAction((ActionEvent event)-> {
            java.io.File file=fileCh.showOpenDialog(primaryStage);
            System.out.println(file.toURI().toString());
            try {
                Image im = new Image(file.toURI().toString());
                ImageView  imv=new ImageView(im);
                imv.setFitHeight(200);
                imv.setFitWidth(200);
                imv.setPreserveRatio(true);
                imv.setLayoutX(20);
                imv.setLayoutY(100);
               // root.getChildren().add(imv);

                java.io.File fileS =   fileCh.showSaveDialog(primaryStage);
                String fileName = fileS.getName();
                String fileExtension = fileName.substring(fileName.indexOf(".") + 1, fileS.getName().length());
                System.out.println(fileExtension);
                ImageIO.write(SwingFXUtils.fromFXImage(imv.getImage(),null), fileExtension, fileS);

            } catch (Exception ex) {
            }
        });

      //  root.getChildren().add(btnFC);

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setTitle("My New Stage Title");
        stage.setScene(new Scene(new Group(), 450, 450));

     //   stage.setFullScreen(true);
    //    stage.setIconified(true);
        stage.setResizable(false);

     //   stage.initModality(Modality.APPLICATION_MODAL);
     //   stage.toBack();

        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
        stage.setX(primaryScreenBounds.getMinX()+100);
        stage.setY(primaryScreenBounds.getMinY()+100);
        stage.setWidth(primaryScreenBounds.getWidth()/2);
        stage.setHeight(primaryScreenBounds.getHeight()/2);

      //  stage.show();

        Popup popup;
        popup=new Popup();
        popup.setAutoHide(true);
        Group rootPopup = new Group();
        rootPopup.getChildren().addAll(new Label("Popup"));
        popup.getContent().addAll(rootPopup);

        Button btnP = new Button("Click me!");
        btnP.setLayoutX(20);
        btnP.setLayoutY(50);
        btnP.setOnMouseClicked((MouseEvent event)->{
                popup.setX(event.getScreenX());
                popup.setY(event.getScreenY());
                popup.show(primaryStage);
        });


      //  root.getChildren().add(btnP);

        pagination = new Pagination(textPages.length/itemsPerPage(), 0);
        pagination.setMaxPageIndicatorCount(5);
        pagination.setPageFactory((Integer pageIndex) -> {
            if (pageIndex >= textPages.length) {
                return null;
            } else {
                return createPage(pageIndex);
            }
        });

    //    root.getChildren().add(pagination);

        // Create the ButtonBar instance
        ButtonBar buttonBar = new ButtonBar();

        // Create the buttons to go into the ButtonBar
        Button yesButton = new Button("Yes");
        yesButton.setPrefWidth(200);
        ButtonBar.setButtonData(yesButton, ButtonBar.ButtonData.YES);

        Button noButton = new Button("No");
        ButtonBar.setButtonData(noButton, ButtonBar.ButtonData.NO);
        ButtonBar.setButtonUniformSize(noButton, false);

        buttonBar.setButtonOrder(ButtonBar.BUTTON_ORDER_LINUX);

        // Add buttons to the ButtonBar
        buttonBar.getButtons().addAll(yesButton, noButton);

      //  root.getChildren().add(buttonBar);

        SplitPane spl=new SplitPane();
        spl.setLayoutX(10);
        spl.setLayoutY(10);
        spl.setCursor(Cursor.TEXT);
        spl.setStyle("-fx-border-width:4pt;-fx-border-color:olive;");
        spl.setPrefSize(400, 300);
        spl.setTooltip(new Tooltip("JavaFX API"));
        spl.setOrientation(Orientation.HORIZONTAL);

        VBox vboxR = new VBox();
        Text textH=new Text("Package javafx.scene.text");
        textH.setStyle("-fx-font:bold 18pt Arial;");
        Text textHC=new Text("Classes");
        textHC.setStyle("-fx-font:bold 18pt Arial");
        Text textC=new Text("Font - represents a font for displaying text\n\nText - a node for displaying text");
        textC.setStyle("-fx-font: 14pt Arial");
        //textC.setWrappingWidth(150);
        vboxR.getChildren().addAll(textH,textHC,textC);
        vboxR.setSpacing(20);

        SplitPane spL=new SplitPane();
        spL.setOrientation(Orientation.VERTICAL);

        VBox vboxLT = new VBox();
        Text textT=new Text("Packeges:\njavafx.scene.text");
        textT.setStyle("-fx-font:bold 12pt Arial");
        vboxLT.getChildren().addAll(textT);
        VBox vboxLB = new VBox();
        Text textB=new Text("Font\nText");
        textB.setStyle("-fx-font:bold 12pt Arial");
        vboxLB.getChildren().addAll(textB);

        spL.getItems().addAll(vboxLT,vboxLB);
        spL.setDividerPositions(0.5);

        spl.getItems().addAll(spL,vboxR);
        spl.setDividerPositions(0.2);

      //  root.getChildren().add(spl);

       Spinner<Integer> spinner = new Spinner<Integer>();
        SpinnerValueFactory.IntegerSpinnerValueFactory valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 5, 2, 1);

        //    Spinner<Double> spinner = new Spinner<Double>();
     //   SpinnerValueFactory<Double> valueFactory = new SpinnerValueFactory.DoubleSpinnerValueFactory(1.1, 5.1, 2.1, 0.1);

     /*   ObservableList<String> months = FXCollections.observableArrayList(
                "January", "February", "March", "April",
                "May", "June", "July", "August",
                "September", "October", "November", "December");

        final Spinner<String> spinner = new Spinner<String>();

        SpinnerValueFactory<String> valueFactory = new SpinnerValueFactory.ListSpinnerValueFactory<String>(months);

        valueFactory.setValue("February");*/

        spinner.setValueFactory(valueFactory);

        spinner.setEditable(true);

        valueFactory.setConverter(new StringConverter<Integer>() {
            @Override
            public String toString(Integer object) {
                return object + "";
            }

            @Override
            public Integer fromString(String string) {
                return Integer.parseInt(string);
            }
        });

        spinner.getEditor().setOnAction((ActionEvent event) ->{
            String text = spinner.getEditor().getText();
            StringConverter<Integer> converter = valueFactory.getConverter();
            Integer enterValue = converter.fromString(text);
            if (enterValue>valueFactory.getMax()) {
                valueFactory.setMax(enterValue);
                valueFactory.setValue(enterValue);
            } else if(enterValue<valueFactory.getMin()){
                valueFactory.setMin(enterValue);
                valueFactory.setValue(enterValue);
            }else{
                valueFactory.setValue(enterValue);
            }
        });

        spinner.valueProperty().addListener(
                (ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue)-> {
                System.out.println(newValue);

        });

      //  root.getChildren().add(spinner);



   /*     String[] styleClasses = new String[] { "", // Default.
                Spinner.STYLE_CLASS_ARROWS_ON_RIGHT_HORIZONTAL,
                Spinner.STYLE_CLASS_ARROWS_ON_LEFT_VERTICAL,
                Spinner.STYLE_CLASS_ARROWS_ON_LEFT_HORIZONTAL,
                Spinner.STYLE_CLASS_SPLIT_ARROWS_VERTICAL,
                Spinner.STYLE_CLASS_SPLIT_ARROWS_HORIZONTAL

        };

        for (String styleClass : styleClasses) {
            Spinner<Integer> spinner = new Spinner<Integer>(1, 20, 10);
            spinner.getStyleClass().add(styleClass);
            root.getChildren().add(spinner);
        }*/


        Label label=new Label("Google:");
        label.setStyle("-fx-font:bold 14pt Arial;");
        label.setPrefSize(100,20);
        label.setAlignment(Pos.CENTER);
        TextField textF=new TextField();
        textF.setCursor(Cursor.TEXT);
        textF.setPrefSize(200,20);
        Button btnSh=new Button("Search");
        btnSh.setStyle("-fx-font:bold 12pt Arial");
        Separator spV=new Separator();
        spV.setOrientation(Orientation.VERTICAL);
        spV.setPrefHeight(20);
        Button btnA=new Button("Custom Search");
        btnA.setStyle("-fx-font:bold 12pt Arial");

        ToolBar toolBar=new ToolBar();
        toolBar.setOrientation(Orientation.HORIZONTAL);
        toolBar.getItems().addAll(label, textF, btnSh, spV, btnA);

     //   root.getChildren().add(toolBar);

        TextArea textArea = new TextArea();
        textArea.setCursor(Cursor.TEXT);
        textArea.setStyle("-fx-padding:5px; -fx-background-radius:20;-fx-border-radius:20;-fx-background-color:#ffefd5;-fx-border-width:5pt;-fx-border-color:#cd853f;-fx-font-weight:bold;-fx-font-size:14pt; -fx-font-family:Georgia; -fx-font-style:italic");
      //  textArea.setPrefSize(300, 250);
        textArea.setPrefWidth(300);
        textArea.setPrefRowCount(5);
        textArea.setTooltip(new Tooltip("Editable text"));
        textArea.setText("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin porta gravida sollicitudin. Cras eu libero lorem. Duis blandit, leo at scelerisque porta, enim magna faucibus nunc, hendrerit placerat eros orci ac augue. Curabitur ac dolor sed velit pharetra placerat ut sit amet quam. Suspendisse et metus ac libero finibus cursus. Ut eget lacus iaculis, gravida lorem a, mattis metus. Proin vel felis sit amet ligula eleifend porta. Etiam varius tempor magna nec pellentesque. Ut a pulvinar lorem. Fusce suscipit porta leo, eu aliquam felis scelerisque sed. Ut mollis ante eu erat semper, at pulvinar lectus mollis.");
        textArea.setEditable(true);
        textArea.setWrapText(true);

        textArea.textProperty().addListener(
                (ObservableValue<? extends String> observable, String oldValue, String newValue)-> {
                    System.out.println(newValue);
        });

      //  root.getChildren().add(textArea);

        TabPane tap=new TabPane();
        tap.setStyle("-fx-border-width:4pt;-fx-border-color:olive;");
        tap.setPrefSize(300, 300);
        tap.setTooltip(new Tooltip("Панель с закладками"));
        tap.setSide(Side.TOP);
        tap.setTabClosingPolicy(TabPane.TabClosingPolicy.SELECTED_TAB);
        tap.setTabMinHeight(20);
        tap.setTabMinWidth(100);

        Tab tabP = new Tab("Images");
        Group rootP = new Group();
        tabP.setContent(rootP);
        Tab tabN = new Tab("Notes");
        Group rootN = new Group();
        tabN.setContent(rootN);

        tap.getTabs().addAll(tabP,tabN);
     //   root.getChildren().add(tap);

        BorderPane bp=new BorderPane();
        bp.setCursor(Cursor.TEXT);
        bp.setStyle("-fx-font:bold 14pt Arial;-fx-text-fill:#a0522d;");
        bp.setPrefSize(300,300);

        Label lT = new Label("Top");
        bp.setTop(lT);
        lT.setStyle("-fx-border-width:2pt;-fx-border-color:olive;");
        lT.setPrefWidth(300);
        lT.setAlignment(Pos.CENTER);
        BorderPane.setAlignment(lT, Pos.CENTER);
        BorderPane.setMargin(lT, new Insets(10, 10, 10,10));

        Label lL = new Label("Left");
        bp.setLeft(lL);
        lL.setStyle("-fx-border-width:2pt;-fx-border-color:olive;");
        lL.setPrefHeight(300);
        BorderPane.setAlignment(lL, Pos.CENTER);
        BorderPane.setMargin(lL, new Insets(10, 10, 10,10));

        Label lR = new Label("Right");
        bp.setRight(lR);;
        lR.setStyle("-fx-border-width:2pt;-fx-border-color:olive;");
        lR.setPrefHeight(100);
        BorderPane.setAlignment(lR, Pos.TOP_LEFT);
        BorderPane.setMargin(lR, new Insets(10, 10, 10,10));

        Label lC = new Label("Center");
        bp.setCenter(lC);;
        lC.setStyle("-fx-border-width:2pt;-fx-border-color:olive;");
        lC.setPrefSize(100,100);
        lC.setAlignment(Pos.CENTER);
        BorderPane.setAlignment(lC, Pos.CENTER);
        BorderPane.setMargin(lC, new Insets(10, 10, 10,10));

        Label lB = new Label("Bottom");
        bp.setBottom(lB);
        lB.setStyle("-fx-border-width:2pt;-fx-border-color:olive;");
        lB.setPrefWidth(300);
        lB.setAlignment(Pos.CENTER);
        BorderPane.setAlignment(lB, Pos.CENTER);
        BorderPane.setMargin(lB, new Insets(10, 10, 10,10));


     //   root.getChildren().add(bp);

        VBox vboxM=new VBox();
        vboxM.setStyle("-fx-font:bold 14pt Arial;-fx-text-fill:#a0522d;-fx-border-width:2pt;-fx-border-color:red;");
        vboxM.setSpacing(10);
        vboxM.setPadding(new Insets(10,10,10,10));
       // vboxM.setFillWidth(false);
        vboxM.setPrefWidth(300);

        HBox hbox1=new HBox();
        hbox1.getChildren().addAll(new Label("Label1"), new Label("Label2"));
        hbox1.setSpacing(20);
        hbox1.setStyle("-fx-border-width:2pt;-fx-border-color:olive;");
        hbox1.setPrefHeight(50);
        hbox1.setPrefWidth(100);

        HBox hbox2=new HBox();
        hbox2.getChildren().addAll(new Label("Label3"), new Label("Label4"));
        hbox2.setSpacing(20);
        hbox2.setStyle("-fx-border-width:2pt;-fx-border-color:olive;");
        hbox2.setPrefHeight(100);
        hbox2.setPrefWidth(100);

        HBox hbox3=new HBox();
        hbox3.getChildren().addAll(new Label("Label5"), new Label("Label6"));
        hbox3.setSpacing(20);
        hbox3.setStyle("-fx-border-width:2pt;-fx-border-color:olive;");
        hbox3.setPrefHeight(150);
        hbox3.setPrefWidth(100);

        vboxM.getChildren().addAll(hbox1, hbox2);

       // root.getChildren().add(vboxM);

        CheckBox cb=new CheckBox();
        cb.setLayoutX(20);
        cb.setLayoutY(50);

        Rectangle rec= new Rectangle(200,40,Color.OLIVE);
        rec.setArcWidth(20);
        rec.setArcHeight(10);

        Text textL=new Text("Receive newsletters");
        DropShadow effectS=new DropShadow();
        effectS.setOffsetX(8);
        effectS.setOffsetY(8);
        textL.setStyle("-fx-font: bold 14pt Arial; -fx-fill:white;");
        textL.setEffect(effectS);

        StackPane stp=new StackPane();
        stp.getChildren().addAll(rec, textL);
        stp.setLayoutX(60);
        stp.setLayoutY(40);
        StackPane.setAlignment(textL, Pos.CENTER);
        StackPane.setMargin(textL, new Insets(10,10,10,10));

     //   root.getChildren().addAll(cb, stp);

        GridPane gpH=new GridPane();
        gpH.setLayoutX(20);
        gpH.setLayoutY(20);
        gpH.setCursor(Cursor.TEXT);
        gpH.setStyle("-fx-font:bold 14pt Arial;-fx-text-fill:#a0522d;");
        gpH.setVgap(10);
        gpH.setGridLinesVisible(true);

        GridPane gp1=new GridPane();
        gp1.addColumn(0, new Label("Label1"), new Label("Label3"));
        gp1.addColumn(1, new Label("Label2"), new Label("Label4"));
        gp1.setVgap(10);

        GridPane gp2=new GridPane();
        gp2.addRow(1, new Label("Label5"), new Label("Label6"));
        gp2.setHgap(20);

        Label lb0 = new Label("Label0");
        GridPane.setColumnSpan(lb0, 2);
        GridPane.setHalignment(lb0, HPos.CENTER);
        Label lb8 = new Label("Label8");
        GridPane.setColumnSpan(lb8, 2);
        GridPane.setHalignment(lb8, HPos.CENTER);

        gpH.addColumn(0,lb0, gp1, gp2, lb8);

       // root.getChildren().addAll(gpH);

        FlowPane fpH=new FlowPane();
        fpH.setStyle("-fx-font:bold 14pt Arial;-fx-text-fill:#a0522d;");
        fpH.setOrientation(Orientation.HORIZONTAL);
        fpH.setPrefWrapLength(500);
        fpH.setHgap(10);
        fpH.setVgap(10);
      //  fpH.setRowValignment(VPos.TOP);

        FlowPane fpV=new FlowPane();
        fpV.setOrientation(Orientation.VERTICAL);
        fpV.setPrefWrapLength(250);
        fpV.setHgap(10);
        fpV.setVgap(10);
        fpV.getChildren().addAll(new Label("Label5"), new Label("Label6"), new Label("Label7"), new Label("Label8"));

        fpH.getChildren().addAll(new Label("Label1"), new Label("Label2"), new Label("Label3"), new Label("Label4"), fpV);

     //   root.getChildren().add(fpH);

        TilePane tpH=new TilePane();
        tpH.setStyle("-fx-font:bold 14pt Arial;-fx-text-fill:#a0522d;");
        tpH.setOrientation(Orientation.HORIZONTAL);
        tpH.setPrefColumns(1);
        tpH.setPrefTileWidth(500);
        tpH.setPrefTileHeight(30);
        tpH.setVgap(10);

        TilePane tp1=new TilePane();
        tp1.setOrientation(Orientation.HORIZONTAL);
        tp1.setPrefColumns(2);
        tp1.getChildren().addAll(new Label("Label1"), new Label("Label2"));
        tp1.setPrefTileWidth(250);

        TilePane tp2=new TilePane();
        tp2.setOrientation(Orientation.HORIZONTAL);
        tp2.setPrefColumns(2);
        tp2.getChildren().addAll(new Label("Label3"), new Label("Label4"));
        tp2.setPrefTileWidth(250);

        tpH.getChildren().addAll(new Label("Label5"), tp1, new Label("Label6"), tp2);

     //   root.getChildren().addAll(tpH);

        AnchorPane ap=new AnchorPane();
        ap.setStyle("-fx-font:bold 14pt Arial;-fx-text-fill:#a0522d;");
        Label lbH1 = new Label("Label1");
        lbH1.setPrefSize(300,30);
        lbH1.setAlignment(Pos.CENTER);
        Label lbH2 = new Label("Label2");
        lbH2.setPrefSize(300,30);
        lbH2.setAlignment(Pos.CENTER);
        AnchorPane.setTopAnchor(lbH1, 10.0);
        AnchorPane.setLeftAnchor(lbH1, 10.0);
        AnchorPane.setTopAnchor(lbH2, 50.0);
        AnchorPane.setLeftAnchor(lbH2, 10.0);
        ap.getChildren().addAll(lbH1, lbH2);

        //root.getChildren().add(ap);

        Arc arcOpen=new Arc();
        arcOpen.setFill(Color.KHAKI);
        arcOpen.setStroke(Color.OLIVE);
        arcOpen.setStrokeWidth(5);
        arcOpen.setStrokeLineCap(StrokeLineCap.ROUND);
        arcOpen.setStrokeType(StrokeType.OUTSIDE);
        arcOpen.setSmooth(true);
        arcOpen.setCenterX(150);
        arcOpen.setCenterY(150);
        arcOpen.setLength(130);
        arcOpen.setRadiusX(80);
        arcOpen.setRadiusY(50);
        arcOpen.setStartAngle(90);
        arcOpen.setType(ArcType.OPEN);

        //root.getChildren().add(arcOpen);

        Line line = new Line();
        line.setStroke(Color.OLIVE);
        line.setStrokeWidth(3);
        line.setStrokeLineCap(StrokeLineCap.ROUND);
        line.setStrokeType(StrokeType.OUTSIDE);
        line.getStrokeDashArray().addAll(5.0,10.0);
        line.setStrokeDashOffset(5);
        line.setStartX(20);
        line.setStartY(20);
        line.setEndX(150);
        line.setEndY(150);

        //root.getChildren().add(line);

        Circle circle=new Circle();
        circle.setFill(Color.KHAKI);
        circle.setStroke(Color.OLIVE);
        circle.setStrokeWidth(5);
        circle.setStrokeType(StrokeType.OUTSIDE);
        circle.setCenterX(150);
        circle.setCenterY(150);
        circle.setRadius(50);

    //    root.getChildren().add(circle);

        CubicCurve cubic = new CubicCurve();
        cubic.setFill(Color.KHAKI);
        cubic.setStroke(Color.OLIVE);
        cubic.setStrokeWidth(3);
        cubic.setStrokeLineCap(StrokeLineCap.ROUND);
        cubic.setStrokeType(StrokeType.CENTERED);
        cubic.setStartX(50);
        cubic.setStartY(80);
        cubic.setEndX(250);
        cubic.setEndY(80);
        cubic.setControlX1(80);
        cubic.setControlY1(10);
        cubic.setControlX2(120);
        cubic.setControlY2(150);

        //root.getChildren().add(cubic);

        QuadCurve quad = new QuadCurve();
        quad.setFill(Color.KHAKI);
        quad.setStroke(Color.OLIVE);
        quad.setStrokeWidth(3);
        quad.setStrokeLineCap(StrokeLineCap.ROUND);
        quad.setStrokeType(StrokeType.CENTERED);
        quad.setStartX(50);
        quad.setStartY(80);
        quad.setEndX(250);
        quad.setEndY(80);
        quad.setControlX(100);
        quad.setControlY(10);

       // root.getChildren().add(quad);

        Ellipse ellipse = new Ellipse();
        ellipse.setFill(Color.KHAKI);
        ellipse.setStroke(Color.OLIVE);
        ellipse.setStrokeWidth(5);
        ellipse.setStrokeType(StrokeType.OUTSIDE);
        ellipse.setCenterX(150);
        ellipse.setCenterY(150);
        ellipse.setRadiusX(80);
        ellipse.setRadiusY(25);

      //  root.getChildren().add(ellipse);

        Rectangle rect = new Rectangle();
        rect.setFill(Color.KHAKI);
        rect.setStroke(Color.OLIVE);
        rect.setStrokeWidth(5);
        rect.setStrokeType(StrokeType.OUTSIDE);
        rect.setHeight(50);
        rect.setWidth(100);
        rect.setX(20);
        rect.setY(20);
        rect.setArcHeight(10);
        rect.setArcWidth(20);

      //  root.getChildren().add(rect);

        Polyline polyline = new Polyline();
        polyline.setFill(Color.KHAKI);
        polyline.setStroke(Color.OLIVE);
        polyline.setStrokeWidth(5);
        polyline.setStrokeLineCap(StrokeLineCap.ROUND);
        polyline.setStrokeLineJoin(StrokeLineJoin.BEVEL);
        polyline.setStrokeType(StrokeType.CENTERED);
        polyline.getPoints().addAll(10.0,10.0,30.0,50.0,60.0,10.0,100.0,80.0,150.0,0.0);

     //   root.getChildren().add(polyline);

        Polygon polygon = new Polygon();
        polygon.setFill(Color.KHAKI);
        polygon.setStroke(Color.OLIVE);
        polygon.setStrokeWidth(5);
        polygon.setStrokeLineCap(StrokeLineCap.ROUND);
        polygon.setStrokeLineJoin(StrokeLineJoin.BEVEL);
        polygon.setStrokeType(StrokeType.CENTERED);
        polygon.getPoints().addAll(10.0,10.0,30.0,50.0,60.0,10.0,100.0,80.0,150.0,0.0);

    //    root.getChildren().add(polygon);

        Path path = new Path();
        path.setFill(Color.KHAKI);
        path.setStroke(Color.OLIVE);
        path.setStrokeWidth(5);
        path.setStrokeType(StrokeType.OUTSIDE);

        MoveTo moveTo = new MoveTo();
        moveTo.setX(50);
        moveTo.setY(100);

        CubicCurveTo cubicToL = new CubicCurveTo();
        cubicToL.setControlX1(0);
        cubicToL.setControlY1(30);
        cubicToL.setControlX2(25);
        cubicToL.setControlY2(0);
        cubicToL.setX(50);
        cubicToL.setY(30);

        CubicCurveTo cubicToR = new CubicCurveTo();
        cubicToR.setControlX1(75);
        cubicToR.setControlY1(0);
        cubicToR.setControlX2(100);
        cubicToR.setControlY2(30);
        cubicToR.setX(50);
        cubicToR.setY(100);

        ClosePath close=new ClosePath();
        path.getElements().addAll(moveTo, cubicToL, cubicToR,close);

        //root.getChildren().add(path);

        SVGPath svg = new SVGPath();
        svg.setFill(Color.KHAKI);
        svg.setStroke(Color.OLIVE);
        svg.setStrokeWidth(5);
        svg.setStrokeType(StrokeType.OUTSIDE);
        svg.setFillRule(FillRule.EVEN_ODD);
        svg.setContent("M50,130 L150,130 L50,200 L100,100 L125,200 Z");

        //root.getChildren().add(svg);

        Text text = new Text();
        text.setLayoutX(0);
        text.setLayoutY(150);
        text.setCursor(Cursor.TEXT);
        DropShadow effectT=new DropShadow();
        effectT.setOffsetX(8);
        effectT.setOffsetY(8);
        text.setEffect(effectT);
        text.setText("Welcome to JavaFX");
        text.setFill(Color.KHAKI);
        text.setStroke(Color.OLIVE);
        text.setStrokeWidth(3);
        text.setStrokeLineJoin(StrokeLineJoin.ROUND);
        text.setStrokeType(StrokeType.OUTSIDE);
        text.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.ITALIC, 40));
        text.setTextAlignment(TextAlignment.CENTER);
        text.setWrappingWidth(500);
        text.setTextOrigin(VPos.BOTTOM);

       // root.getChildren().add(text);

        StackPane stack = new StackPane();
        ScrollPane sclp = new ScrollPane();
        sclp.setContent(stack);
        sclp.setPrefSize(200,200);
        sclp.setLayoutX(10);
        sclp.setLayoutY(10);

        FileChooser fileChooser=new FileChooser();
        Button btnLoad = new Button("Load Image");
        btnLoad.setLayoutX(300);
        btnLoad.setLayoutY(10);
        btnLoad.setOnMouseClicked((MouseEvent event) -> {
            try {
                fileChooser.setInitialDirectory(new java.io.File("C:/"));
                fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Image",  "*.bmp", "*.png", "*.jpg", "*.gif"));
                fileChooser.setTitle("Select Image");
                File fileLoad =fileChooser.showOpenDialog(primaryStage);
                Image im = new Image(fileLoad.toURI().toString());
                ImageView imv=new ImageView(im);
                imv.setFitHeight(500);
                imv.setFitWidth(500);
                imv.setPreserveRatio(true);
                stack.getChildren().add(imv);
            } catch (Exception ex) {
            }});

        Button btnSave = new Button("Save Image");
        btnSave.setLayoutX(300);
        btnSave.setLayoutY(50);
        btnSave.setOnMouseClicked((MouseEvent event)-> {
              /*  try {
                    Robot robot = new Robot();
                    int x= (int) primaryStage.getX()+(int)stack.getLayoutX()+(int)primaryStage.getScene().getX();
                    int y= (int) primaryStage.getY()+(int)stack.getLayoutY()+(int)primaryStage.getScene().getY();
                    int width=(int)stack.getLayoutBounds().getWidth();
                    int height=(int)stack.getLayoutBounds().getHeight();
                    java.awt.Rectangle rc=new java.awt.Rectangle(x,y,width,height);
                    BufferedImage screenShot = robot.createScreenCapture(rc);
                    fileChooser.setInitialDirectory(new java.io.File("C:/"));
                    fileChooser.setTitle("Save Image");
                    java.io.File file=fileChooser.showSaveDialog(primaryStage);
                    int extIndex=file.getPath().lastIndexOf(".");
                    String ext=file.getPath().substring(extIndex+1);
                    ImageIO.write(screenShot, ext, file);
                } catch (Exception ex) {
                }*/

            WritableImage wimg = stack.snapshot(new SnapshotParameters(), null);
            BufferedImage screenShot = SwingFXUtils.fromFXImage(wimg, null);
            fileChooser.setInitialDirectory(new java.io.File("C:/"));
            fileChooser.getExtensionFilters().clear();
            fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Image", "*.png"));
            fileChooser.setTitle("Save Image");
            java.io.File file=fileChooser.showSaveDialog(primaryStage);
            try {
                ImageIO.write(screenShot, "png", file);
            } catch (Exception ex) {
            }
    });


     //   root.getChildren().addAll(sclp, btnLoad, btnSave);

        WebView webView=new WebView();
        webView.setPrefSize(400, 400);
        webView.setCursor(Cursor.TEXT);
        webView.getEngine().loadContent("<html><body bgcolor=#A0BEC4></body></html>");

        TextField textField = new TextField();
        textField.setCursor(Cursor.TEXT);
        textField.setStyle("-fx-background-radius:10;-fx-border-radius:8;-fx-background-color:#ffefd5;-fx-border-width:3pt;-fx-border-color:#cd853f;-fx-font-weight:bold;-fx-font-size:14pt; -fx-font-family:Georgia; -fx-font-style:italic");
        textField.setPrefWidth(400);
        textField.setTooltip(new Tooltip("Input an adress"));
        textField.setEditable(true);
        textField.setPromptText("http://google.com/");
        textField.setOnAction((ActionEvent e)-> {
                if(!textField.getText().isEmpty())
                    webView.getEngine().load(textField.getText());
            });

        Button btnW = new Button();
        btnW.setText("->");
        btnW.setCursor(Cursor.CLOSED_HAND);
        btnW.setStyle("-fx-font: bold 16pt Georgia;-fx-text-fill: white;-fx-background-color: #a0522d;-fx-border-width: 3px; -fx-border-color:#f4a460 #800000 #800000 #f4a460;" );
        btnW.setOnAction((ActionEvent e)-> {
                if(!textField.getText().isEmpty()) {
                    // webView.getEngine().load(textField.getText());
                    PrinterJob job = PrinterJob.createPrinterJob();
                    job.showPageSetupDialog(primaryStage);
                    job.showPrintDialog(primaryStage);
                    if (job != null) {
                        webView.getEngine().print(job);
                        job.endJob();
                    }
                }
            });

        webView.getEngine().locationProperty().addListener(
                (ObservableValue<? extends String> ov,String old_value, String new_value)-> {
                textField.setText(new_value);
            });

        ProgressIndicator pi = new ProgressIndicator();
        pi.setLayoutX(200);
        pi.setLayoutY(200);
        pi.setCursor(Cursor.TEXT);
        pi.setTooltip(new Tooltip("Loading Web page"));
        pi.setPrefSize(70,70);
        pi.setProgress(-1.0);
        pi.setVisible(false);

        webView.getEngine().getLoadWorker().progressProperty().addListener(
                (ObservableValue<? extends Number> ov,  Number old_val, Number new_val)-> {
                if (new_val.doubleValue()!=1.0)
                    pi.setVisible(true);
                else pi.setVisible(false);
            });

        HBox hb = new HBox();
        hb.getChildren().addAll(textField, btnW);
        VBox vb = new VBox();
        vb.getChildren().addAll(hb,webView);
       // root.getChildren().addAll(vb, pi);

    /*    String MEDIA_URL =
                "http://download.oracle.com/otndocs/products/javafx/oow2010-2.flv";
        Media media = new Media(MEDIA_URL);
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        mediaPlayer.setAutoPlay(true);
        MediaView mediaView = new MediaView(mediaPlayer);

        root.getChildren().add(mediaView);*/

        Button btnE = new Button();
        btnE.setLayoutX(100);
        btnE.setLayoutY(100);
        btnE.setText("Next");
        btnE.setPrefSize(100,50);
       // btnE.setStyle("-fx-font:italic bold 18pt Georgia; -fx-text-fill: white;-fx-background-color:black;");
        btnE.setStyle("-fx-font: bold italic 14pt Georgia;-fx-text-fill: white;-fx-background-color: #a0522d;-fx-border-width: 3px; -fx-border-color:#f4a460 #800000 #800000 #f4a460;");

        Stop[] stops = new Stop[] {new Stop(0, Color.RED), new Stop(1, Color.YELLOW)};
        LinearGradient lg = new LinearGradient(0, 0, 0.25, 0.25, true, CycleMethod.REFLECT, stops);

        ColorInput colorInput = new ColorInput();
        colorInput.setWidth(100);
        colorInput.setHeight(50);
        colorInput.setPaint(lg);

        Blend blend = new Blend();
        blend.setMode(BlendMode.SRC_OVER);
      //  blend.setBottomInput(colorInput);
        blend.setTopInput(colorInput);

        Bloom bloom=new Bloom();
        bloom.setThreshold(0.3);


        btnE.setOnMouseEntered((MouseEvent event)-> {
                btnE.setEffect(bloom);
            });
        btnE.setOnMouseExited((MouseEvent event)-> {
                btnE.setEffect(null);
            });

      //  root.getChildren().add(btnE);

        Button btnG = new Button();
        btnG.setText("Next");
        btnG.setPrefSize(100,30);
        btnG.setStyle("-fx-font: bold italic 14pt Georgia;-fx-text-fill: white;-fx-background-color: #a0522d;-fx-border-width: 3px; -fx-border-color:#f4a460 #800000 #800000 #f4a460;");
        Glow glow=new Glow();
        glow.setLevel(0.0);
        Timeline timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.setAutoReverse(true);
        KeyValue kv = new KeyValue(glow.levelProperty(), 1.0);
        KeyFrame kf = new KeyFrame(Duration.millis(2000), kv);
        timeline.getKeyFrames().add(kf);
        timeline.play();
        Rectangle r = new Rectangle();
        r.setWidth(130);
        r.setHeight(80);
        r.setArcHeight(20);
        r.setArcWidth(20);
        r.setFill(Color.web("#f4a460"));
        r.setStroke(Color.WHITE);
        r.setStrokeWidth(5);
        r.setStrokeType(StrokeType.OUTSIDE);
        r.setEffect(glow);
        StackPane pane=new StackPane();
        pane.getChildren().addAll(r,btnG);
        pane.setLayoutX(100);
        pane.setLayoutY(100);

      //  root.getChildren().add(pane);

        VBox vboxE=new VBox();
        vboxE.setLayoutX(20);
        vboxE.setLayoutY(50);
        vboxE.setSpacing(50);
        final DropShadow effectD=new DropShadow();
        effectD.setColor(Color.OLIVE);
        Text textE = new Text();
        textE.setEffect(effectD);
        textE.setText("JavaFX");
        textE.setFill(Color.KHAKI);
        textE.setStroke(Color.OLIVE);
        textE.setStrokeWidth(3);
        textE.setStrokeLineJoin(StrokeLineJoin.ROUND);
        textE.setStrokeType(StrokeType.OUTSIDE);
        textE.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.ITALIC, 40));
        textE.setTextAlignment(TextAlignment.CENTER);
        textE.setCache(true);
        TilePane paneEf=new TilePane();
        paneEf.setHgap(5);
        paneEf.setVgap(10);
        paneEf.setPrefColumns(2);
        Label labelRadius=new Label("radius");
        Slider sliderRadius=new Slider();
        sliderRadius.setPrefWidth(100);
        sliderRadius.setMin(0.0);
        sliderRadius.setMax(127.0);
        effectD.radiusProperty().bind(sliderRadius.valueProperty());
        Label labelSpread=new Label("spread");
        Slider sliderSpread=new Slider();
        sliderSpread.setPrefWidth(100);
        sliderSpread.setMin(0.0);
        sliderSpread.setMax(1.0);
        effectD.spreadProperty().bind(sliderSpread.valueProperty());
        Label labelOffsetX=new Label("offsetX");
        Slider sliderOffsetX=new Slider();
        sliderOffsetX.setPrefWidth(100);
        sliderOffsetX.setMin(0.0);
        sliderOffsetX.setMax(50.0);
        effectD.offsetXProperty().bind(sliderOffsetX.valueProperty());
        Label labelOffsetY=new Label("offsetY");
        Slider sliderOffsetY=new Slider();
        sliderOffsetY.setPrefWidth(100);
        sliderOffsetY.setMin(0.0);
        sliderOffsetY.setMax(50.0);
        effectD.offsetYProperty().bind(sliderOffsetY.valueProperty());
        paneEf.getChildren().addAll(labelRadius,sliderRadius,labelSpread, sliderSpread,labelOffsetX, sliderOffsetX, labelOffsetY, sliderOffsetY);
        vboxE.getChildren().addAll(textE,paneEf);

       // root.getChildren().add(vboxE);

        Shadow effectSw=new Shadow();
        effectSw.setColor(Color.web("#a0522d"));
        Button btnSw = new Button();
        btnSw.setPrefSize(150,80);
        btnSw.setEffect(effectSw);
        Timeline timelineSw = new Timeline();
        timelineSw.setCycleCount(Timeline.INDEFINITE);
        timelineSw.setAutoReverse(true);
        KeyValue kvSw = new KeyValue(btnSw.opacityProperty(), 0.0);
        KeyFrame kfSw = new KeyFrame(Duration.millis(2000), kvSw);
        timelineSw.getKeyFrames().add(kfSw);
        timelineSw.play();
        Button btnF = new Button();
        btnF.setText("Next");
        btnF.setPrefSize(100,30);
        btnF.setStyle("-fx-font: bold italic 14pt Georgia;-fx-text-fill: white;-fx-background-color: #a0522d;-fx-border-width: 3px; -fx-border-color:#f4a460 #800000 #800000 #f4a460;");
        StackPane paneSw=new StackPane();
        paneSw.getChildren().addAll(btnSw,btnF);
        paneSw.setLayoutX(100);
        paneSw.setLayoutY(100);

//root.getChildren().add(paneSw);

        InnerShadow effectIs=new InnerShadow();
        effectIs.setColor(Color.OLIVE);
        Text textIs = new Text();
        textIs.setLayoutX(20);
        textIs.setLayoutY(100);
        textIs.setEffect(effectIs);
        textIs.setText("JavaFX");
        textIs.setFill(Color.KHAKI);
        textIs.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.ITALIC, 80));
        textIs.setTextAlignment(TextAlignment.CENTER);
        textIs.setCache(true);
        TilePane paneIs=new TilePane();
        paneIs.setLayoutX(20);
        paneIs.setLayoutY(200);
        paneIs.setHgap(5);
        paneIs.setVgap(10);
        paneIs.setPrefColumns(2);
        Label labelRadiusIs=new Label("radius");
        Slider sliderRadiusIs=new Slider();
        sliderRadiusIs.setPrefWidth(100);
        sliderRadiusIs.setMin(0.0);
        sliderRadiusIs.setMax(127.0);
        effectIs.radiusProperty().bind(sliderRadiusIs.valueProperty());
        Label labelChokeIs =new Label("choke");
        Slider sliderChokeIs =new Slider();
        sliderChokeIs.setPrefWidth(100);
        sliderChokeIs.setMin(0.0);
        sliderChokeIs.setMax(1.0);
        effectIs.chokeProperty().bind(sliderChokeIs.valueProperty());
        Label labelOffsetXIs=new Label("offsetX");
        Slider sliderOffsetXIs=new Slider();
        sliderOffsetXIs.setPrefWidth(100);
        sliderOffsetXIs.setMin(0.0);
        sliderOffsetXIs.setMax(50.0);
        effectIs.offsetXProperty().bind(sliderOffsetXIs.valueProperty());
        Label labelOffsetYIs=new Label("offsetY");
        Slider sliderOffsetYIs=new Slider();
        sliderOffsetYIs.setPrefWidth(100);
        sliderOffsetYIs.setMin(0.0);
        sliderOffsetYIs.setMax(50.0);
        effectIs.offsetYProperty().bind(sliderOffsetYIs.valueProperty());
        paneIs.getChildren().addAll(labelRadiusIs,sliderRadiusIs,labelChokeIs, sliderChokeIs,labelOffsetXIs, sliderOffsetXIs, labelOffsetYIs, sliderOffsetYIs);

       // root.getChildren().addAll(textIs,paneIs);

        BoxBlur blur=new BoxBlur();
        blur.setWidth(0.0);
        blur.setHeight(0.0);
        Button btnB = new Button();
        btnB.setLayoutX(50);
        btnB.setLayoutY(100);
        btnB.setPrefSize(200,20);
        btnB.setText("Hello World!");
        btnB.setStyle("-fx-font:bold 18pt Arial");
        btnB.setEffect(blur);
        Timeline timelineB = new Timeline();
        timelineB.setCycleCount(Timeline.INDEFINITE);
        timelineB.setAutoReverse(true);
        KeyValue kvO = new KeyValue(btnB.opacityProperty(), 0.0);
        KeyFrame kfO = new KeyFrame(Duration.millis(5000), kvO);
        KeyValue kvB = new KeyValue(blur.widthProperty(),50);
        KeyFrame kfB = new KeyFrame(Duration.millis(5000), kvB);
        timelineB.getKeyFrames().addAll(kfO,kfB);
        timelineB.play();

//root.getChildren().add(btnB);

        MotionBlur mb = new MotionBlur();
        mb.setRadius(15.0);
        mb.setAngle(90.0);
        TitledPane tpM =new TitledPane();
        tpM.setLayoutX(10);
        tpM.setLayoutY(10);
        tpM.setCursor(Cursor.CROSSHAIR);
        tpM.setStyle("-fx-border-width:4pt;-fx-border-color:olive;");
        tpM.setExpanded(true);
        tpM.setPrefHeight(300);
        Label labelM = new Label("Motion");
        labelM.setCursor(Cursor.CLOSED_HAND);
        labelM.setPrefSize(300,30);
        labelM.setStyle("-fx-font: bold italic 16pt Georgia;-fx-text-fill:black;-fx-background-color:#e6e6fa;");
        labelM.setAlignment(Pos.CENTER);

        tpM.setContent(labelM);
        tpM.expandedProperty().addListener((ObservableValue<? extends Boolean> ov,
                                Boolean old_val, Boolean new_val)-> {
            if(new_val!=true) {
                labelM.setEffect(mb);
            }else{
                labelM.setEffect(null);
            }
            });

//root.getChildren().add(tpM);

        GaussianBlur blurG=new GaussianBlur();
        blurG.setRadius(0.0);
        Button btnGb = new Button();
        btnGb.setLayoutX(50);
        btnGb.setLayoutY(100);
        btnGb.setPrefSize(200,20);
        btnGb.setText("Hello World!");
        btnGb.setStyle("-fx-font:bold 18pt Arial");
        btnGb.setEffect(blurG);
        Timeline timelineGb = new Timeline();
        timelineGb.setCycleCount(Timeline.INDEFINITE);
        timelineGb.setAutoReverse(true);
        KeyValue kvOGb = new KeyValue(btnGb.opacityProperty(), 0.0);
        KeyFrame kfOGb = new KeyFrame(Duration.millis(5000), kvOGb);
        KeyValue kvBGb = new KeyValue(blurG.radiusProperty(),63.0);
        KeyFrame kfBGb = new KeyFrame(Duration.millis(5000), kvBGb);
        timelineGb.getKeyFrames().addAll(kfOGb,kfBGb);
        timelineGb.play();

     //   root.getChildren().add(btnGb);

        ColorAdjust effectCa=new ColorAdjust();
        effectCa.setBrightness(0.3);
        effectCa.setContrast(0.5);
        effectCa.setHue(0.5);
        effectCa.setSaturation(0.5);
        ToggleButton btnOn = new ToggleButton("JavaFX");
        btnOn.setLayoutX(30);
        btnOn.setLayoutY(50);
        btnOn.setCursor(Cursor.CLOSED_HAND);
        btnOn.setTextAlignment(TextAlignment.CENTER);
        btnOn.setPrefSize(200,50);
        btnOn.setStyle("-fx-base:#9900ff;-fx-font: bold italic 18pt Georgia;-fx-text-fill:white;");
        btnOn.selectedProperty().addListener(
                (ObservableValue<? extends Boolean> ov, Boolean old_val, Boolean new_val)-> {
                if (new_val.equals(Boolean.TRUE)){
                    btnOn.setEffect(effectCa);
                }
                if (new_val.equals(Boolean.FALSE)){
                    btnOn.setEffect(null);
                 }});

//root.getChildren().add(btnOn);

        int w = 200;
        int h = 80;
        FloatMap map1 = new FloatMap();
        map1.setWidth(w);
        map1.setHeight(h);
        for (int i = 0; i < w; i++) {
            double v = (Math.sin(i/50.0*Math.PI))/40.0;
            for (int j = 0; j < h; j++) {
                map1.setSamples(i, j, 0.0f,(float) v);
            }}

        FloatMap map2 = new FloatMap();
        map2.setWidth(w);
        map2.setHeight(h);
        for (int i = 0; i < w; i++) {
            double v = -(Math.sin(i/50.0*Math.PI))/40.0;
            for (int j = 0; j < h; j++) {
                map2.setSamples(i, j, 0.0f,(float) v);
            }}

        DisplacementMap dm = new DisplacementMap();
        dm.setMapData(map1);
        Button btnDis = new Button("JavaFX");
        btnDis.setLayoutX(50);
        btnDis.setLayoutY(50);
        btnDis.setPrefSize(200, 80);
        btnDis.setStyle("-fx-base:#9900ff;-fx-font: bold italic 18pt Georgia;-fx-text-fill:white;");
        btnDis.setEffect(dm);
        AnimationTimer timer=new AnimationTimer(){
            public void handle(long now){
                if((now/200000000)%2==0)dm.setMapData(map2);
                else dm.setMapData(map1);
            }};
        timer.start();

   //     root.getChildren().add(btnDis);


        Light.Distant lightDistant = new Light.Distant();
        Light.Point lightPoint = new Light.Point();
        Light.Spot lightSpot = new Light.Spot();
        Lighting effectL = new Lighting();
        effectL.setLight(lightDistant);

        Button btnL = new Button("Submit");
        btnL.setLayoutX(30);
        btnL.setLayoutY(30);
        btnL.setCursor(Cursor.CLOSED_HAND);
        btnL.setStyle("-fx-font: bold italic 14pt Georgia;-fx-text-fill: white;-fx-background-color: #a0522d;" );
        btnL.setPrefSize(180,30);
        btnL.setEffect(effectL);

        btnL.setOnMousePressed((MouseEvent event)-> {
                btnL.setEffect(null);
            });
        btnL.setOnMouseReleased((MouseEvent event)-> {
                btnL.setEffect(effectL);
            });

        TilePane paneE=new TilePane();
        paneE.setLayoutX(20);
        paneE.setLayoutY(100);
        paneE.setHgap(5);
        paneE.setVgap(10);
        paneE.setPrefColumns(2);

        Label labelDiffuseConstant=new Label("diffuseConstant");
        Slider sliderDiffuseConstant=new Slider();
        sliderDiffuseConstant.setValue(1.0);
        sliderDiffuseConstant.setPrefWidth(200);
        sliderDiffuseConstant.setMin(0.0);
        sliderDiffuseConstant.setMax(2.0);
        effectL.diffuseConstantProperty().bind(sliderDiffuseConstant.valueProperty());
        Label labelSpecularConstant=new Label("specularConstant");
        Slider sliderSpecularConstant=new Slider();
        sliderSpecularConstant.setValue(0.3);
        sliderSpecularConstant.setPrefWidth(200);
        sliderSpecularConstant.setMin(0.0);
        sliderSpecularConstant.setMax(2.0);
        effectL.specularConstantProperty().bind(sliderSpecularConstant.valueProperty());
        Label labelSurfaceScale=new Label("surfaceScale");
        Slider sliderSurfaceScale=new Slider();
        sliderSurfaceScale.setValue(1.5);
        sliderSurfaceScale.setPrefWidth(200);
        sliderSurfaceScale.setMin(0.0);
        sliderSurfaceScale.setMax(10.0);
        effectL.surfaceScaleProperty().bind(sliderSurfaceScale.valueProperty());
        paneE.getChildren().addAll(labelDiffuseConstant,sliderDiffuseConstant,labelSpecularConstant, sliderSpecularConstant,labelSurfaceScale, sliderSurfaceScale);

        TilePane paneL=new TilePane();
        paneL.setLayoutX(20);
        paneL.setLayoutY(200);
        paneL.setHgap(5);
        paneL.setVgap(10);
        paneL.setPrefColumns(2);

        Label labelDistantAzimuth=new Label("azimuth");
        Slider sliderDistantAzimuth=new Slider();
        sliderDistantAzimuth.setValue(45.0);
        sliderDistantAzimuth.setPrefWidth(200);
        sliderDistantAzimuth.setMin(-360.0);
        sliderDistantAzimuth.setMax(360.0);
        lightDistant.azimuthProperty().bind(sliderDistantAzimuth.valueProperty());

        Label labelDistantElevation=new Label("elevation");
        Slider sliderDistantElevation=new Slider();
        sliderDistantElevation.setValue(45.0);
        sliderDistantElevation.setPrefWidth(200);
        sliderDistantElevation.setMin(-360.0);
        sliderDistantElevation.setMax(360.0);
        lightDistant.elevationProperty().bind(sliderDistantElevation.valueProperty());
        Label labelPointX=new Label("X");
        Slider sliderPointX=new Slider();
        sliderPointX.setPrefWidth(200);
        sliderPointX.setMin(-500.0);
        sliderPointX.setMax(500.0);
        lightPoint.xProperty().bind(sliderPointX.valueProperty());
        lightSpot.xProperty().bind(sliderPointX.valueProperty());
        Label labelPointY=new Label("Y");
        Slider sliderPointY=new Slider();
        sliderPointY.setPrefWidth(200);
        sliderPointY.setMin(-500.0);
        sliderPointY.setMax(500.0);
        lightPoint.yProperty().bind(sliderPointY.valueProperty());
        lightSpot.yProperty().bind(sliderPointY.valueProperty());
        Label labelPointZ=new Label("Z");
        Slider sliderPointZ=new Slider();
        sliderPointZ.setValue(500.0);
        sliderPointZ.setPrefWidth(200);
        sliderPointZ.setMin(0.0);
        sliderPointZ.setMax(1000.0);
        lightPoint.zProperty().bind(sliderPointZ.valueProperty());
        lightSpot.zProperty().bind(sliderPointZ.valueProperty());
        Label labelSpotPointsAtX =new Label("pointsAtX");
        Slider sliderSpotPointsAtX=new Slider();
        sliderSpotPointsAtX.setPrefWidth(200);
        sliderSpotPointsAtX.setMin(-500.0);
        sliderSpotPointsAtX.setMax(500.0);
        lightSpot.pointsAtXProperty().bind(sliderSpotPointsAtX.valueProperty());
        Label labelSpotPointsAtY =new Label("pointsAtY");
        Slider sliderSpotPointsAtY=new Slider();
        sliderSpotPointsAtY.setPrefWidth(200);
        sliderSpotPointsAtY.setMin(-500.0);
        sliderSpotPointsAtY.setMax(500.0);
        lightSpot.pointsAtYProperty().bind(sliderSpotPointsAtY.valueProperty());
        Label labelSpotPointsAtZ=new Label("pointsAtZ");
        Slider sliderSpotPointsAtZ=new Slider();
        sliderSpotPointsAtZ.setPrefWidth(200);
        sliderSpotPointsAtZ.setMin(0.0);
        sliderSpotPointsAtZ.setMax(1000.0);
        lightSpot.pointsAtZProperty().bind(sliderSpotPointsAtZ.valueProperty());
        Label labelSpecularExponent=new Label("specularExponent");
        Slider sliderSpecularExponent=new Slider();
        sliderSpecularExponent.setValue(1.0);
        sliderSpecularExponent.setPrefWidth(200);
        sliderSpecularExponent.setMin(0.0);
        sliderSpecularExponent.setMax(4.0);
        lightSpot.specularExponentProperty().bind(sliderSpecularExponent.valueProperty());
        paneL.getChildren().addAll(labelDistantAzimuth,sliderDistantAzimuth, labelDistantElevation, sliderDistantElevation);

        Button btnDistant = new Button("Light.Distant");
        btnDistant.setLayoutX(10);
        btnDistant.setLayoutY(400);
        btnDistant.setCursor(Cursor.CLOSED_HAND);
        btnDistant.setOnAction((ActionEvent event)-> {
                effectL.setLight(lightDistant);
                paneL.getChildren().clear();
                paneL.getChildren().addAll(labelDistantAzimuth,sliderDistantAzimuth, labelDistantElevation, sliderDistantElevation);
            });
        Button btnPoint = new Button("Light.Point");
        btnPoint.setLayoutX(170);
        btnPoint.setLayoutY(400);
        btnPoint.setCursor(Cursor.CLOSED_HAND);
        btnPoint.setOnAction((ActionEvent event)-> {
                effectL.setLight(lightPoint);
                paneL.getChildren().clear();
                paneL.getChildren().addAll(labelPointX,sliderPointX, labelPointY,sliderPointY, labelPointZ,sliderPointZ);
            });
        Button btnSpot = new Button("Light.Spot");
        btnSpot.setLayoutX(300);
        btnSpot.setLayoutY(400);
        btnSpot.setCursor(Cursor.CLOSED_HAND);
        btnSpot.setOnAction((ActionEvent event)-> {
                effectL.setLight(lightSpot);
                paneL.getChildren().clear();
                paneL.getChildren().addAll(labelPointX,sliderPointX, labelPointY,sliderPointY, labelPointZ,sliderPointZ, labelSpotPointsAtX,sliderSpotPointsAtX, labelSpotPointsAtY,sliderSpotPointsAtY, labelSpotPointsAtZ,sliderSpotPointsAtZ, labelSpecularExponent,sliderSpecularExponent);
            });

       // root.getChildren().addAll(btnL,paneE,paneL,btnDistant, btnPoint, btnSpot);

        Stop[] stopsR = new Stop[] { new Stop(0, Color.LIGHTGRAY), new Stop(0.8, Color.WHITE)};
        LinearGradient lgR = new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE, stopsR);
        Rectangle rct = new Rectangle(300,150);
        rct.setLayoutX(20);
        rct.setLayoutY(100);
        rct.setFill(lgR);
        PerspectiveTransform pt=new PerspectiveTransform();
        pt.setLlx(rct.getX()+35);
        pt.setLrx(rct.getX()+rct.getWidth()+35);
        pt.setLly(rct.getY()+rct.getHeight());
        pt.setLry(rct.getY()+rct.getHeight());
        pt.setUlx(rct.getX());
        pt.setUly(rct.getY()+30);
        pt.setUrx(rct.getX()+rct.getWidth());
        pt.setUry(rct.getY()+30);
        rct.setEffect(pt);
        Text textR = new Text("JavaFX");
        textR.setLayoutX(60);
        textR.setLayoutY(150);
        InnerShadow is = new InnerShadow();
        is.setOffsetX(4.0f);
        is.setOffsetY(4.0f);
        Reflection effectR=new Reflection();
        effectR.setBottomOpacity(0.0);
        effectR.setFraction(0.7);
        effectR.setTopOffset(-65.0);
        effectR.setTopOpacity(0.7);
        effectR.setInput(is);
        textR.setEffect(effectR);
        textR.setFill(Color.LIGHTBLUE);
        textR.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.ITALIC, 60));
        textR.setTextAlignment(TextAlignment.CENTER);


     //   root.getChildren().addAll(rct,textR);

        PhongMaterial material = new PhongMaterial();
      //  material.setSpecularColor(Color.WHITE);
      //  material.setDiffuseColor(Color.BLUE);
      //  material.setSpecularPower(200);
        String DIFFUSE_MAP =
                "http://planetmaker.wthr.us/img/earth_gebco8_texture_8192x4096.jpg";
        String NORMAL_MAP =
                "http://planetmaker.wthr.us/img/earth_normalmap_flat_8192x4096.jpg";
        String SPECULAR_MAP =
                "http://planetmaker.wthr.us/img/earth_specularmap_flat_8192x4096.jpg";
        material.setBumpMap( new Image( NORMAL_MAP, 200, 200, true, true));
        material.setSpecularMap( new Image( SPECULAR_MAP, 200, 200, true, true));
        material.setDiffuseMap( new Image( DIFFUSE_MAP, 200, 200, true, true));
     //  material.setSelfIlluminationMap( new Image( DIFFUSE_MAP, 200, 200, true, true));

        Box box = new Box(200, 200, 200);
        box.setTranslateX(250);
        box.setTranslateY(250);
        box.setTranslateZ(200);
        box.setMaterial(material);

      //  box.setDrawMode(DrawMode.LINE);
      //  box.setCullFace(CullFace.NONE);

        box.setRotationAxis(Rotate.X_AXIS);
       // box.setRotate(30);
        Rotate rotate = new Rotate();
        rotate.setAngle(20);
        rotate.setPivotX(250);
        rotate.setPivotY(250);
      //  box.getTransforms().addAll(rotate);

        PointLight light = new PointLight();
        light.setTranslateX(400);
        light.setTranslateY(400);
        light.setTranslateZ(-200);

        PerspectiveCamera camera = new PerspectiveCamera(true);

        camera.setTranslateX(250);
        camera.setTranslateY(250);
        camera.setFarClip(2000.0);
        camera.setTranslateZ(-300);
     //   camera.setNearClip(3000);
        camera.setFieldOfView(80);


        Group rootSub = new Group();
        SubScene subScene = new SubScene(rootSub, 600, 200);
        rootSub.getChildren().addAll(box, light);
        subScene.setCamera(camera);

    //    root.getChildren().add(subScene);

        TilePane pane3D=new TilePane();
        pane3D.setHgap(5);
        pane3D.setVgap(10);
        pane3D.setPrefColumns(2);
        pane3D.setLayoutX(50);
        pane3D.setLayoutY(250);

        Label labelLX=new Label("Light X");
        Slider sliderLX=new Slider();
        sliderLX.setPrefWidth(200);
        sliderLX.setMin(-1000.0);
        sliderLX.setMax(1000.0);
        light.translateXProperty().bind(sliderLX.valueProperty());

        Label labelLY=new Label("Light Y");
        Slider sliderLY=new Slider();
        sliderLY.setPrefWidth(200);
        sliderLY.setMin(-1000.0);
        sliderLY.setMax(1000.0);
        light.translateYProperty().bind(sliderLY.valueProperty());

        Label labelLZ=new Label("Light Z");
        Slider sliderLZ=new Slider();
        sliderLZ.setPrefWidth(200);
        sliderLZ.setMin(-1000.0);
        sliderLZ.setMax(1000.0);
        light.translateZProperty().bind(sliderLZ.valueProperty());

        Label labelCX=new Label("Camera X");
        Slider sliderCX=new Slider();
        sliderCX.setPrefWidth(200);
        sliderCX.setMin(-500.0);
        sliderCX.setMax(500.0);
        camera.translateXProperty().bind(sliderCX.valueProperty());

        Label labelCY=new Label("Camera Y");
        Slider sliderCY=new Slider();
        sliderCY.setPrefWidth(200);
        sliderCY.setMin(-500.0);
        sliderCY.setMax(500.0);
        camera.translateYProperty().bind(sliderCY.valueProperty());

        Label labelCZ=new Label("Camera Z");
        Slider sliderCZ=new Slider();
        sliderCZ.setPrefWidth(200);
        sliderCZ.setMin(-1000.0);
        sliderCZ.setValue(-500);
        sliderCZ.setMax(0.0);
        camera.translateZProperty().bind(sliderCZ.valueProperty());

        Label labelCR=new Label("Camera R");
        Slider sliderCR=new Slider();
        sliderCR.setPrefWidth(200);
        sliderCR.setMin(0.0);
        sliderCR.setMax(360.0);
        camera.rotateProperty().bind(sliderCR.valueProperty());

        pane3D.getChildren().addAll(labelLX, sliderLX, labelLY, sliderLY, labelLZ, sliderLZ,labelCX, sliderCX, labelCY, sliderCY, labelCZ, sliderCZ, labelCR, sliderCR);

      //  root.getChildren().addAll(pane3D);

        scene.setOnMouseClicked((MouseEvent event)-> {
            if(event.getPickResult().getIntersectedNode()!=null)
                System.out.println(event.getPickResult().getIntersectedNode().getClass().getName());
            }
        );

        ObservableList<PieChart.Data> pieChartData =
                FXCollections.observableArrayList(
                        new PieChart.Data("Доллар США",45.9),
                        new PieChart.Data("Евро",42.5),
                        new PieChart.Data("Японская иена",1.6),
                        new PieChart.Data("Фунт стерлингов",9.2),
                        new PieChart.Data("Канадский доллар",0.8));
        PieChart chart = new PieChart(pieChartData);
        chart.setLayoutX(50);
        chart.setLayoutY(10);
        chart.setCursor(Cursor.CROSSHAIR);
        chart.setStyle("-fx-font:bold 14 Arial; -fx-text-fill:brown;");
        chart.setPrefSize(500, 400);
        chart.setAnimated(true);
        chart.setTitle("Распределение валютных активов\n Банка России по валютам в 2010 г.");
        chart.setTitleSide(Side.TOP);
        chart.setLegendVisible(true);
        chart.setLegendSide(Side.BOTTOM);
        chart.setClockwise(true);
        chart.setLabelsVisible(true);
        chart.setLabelLineLength(20);
        chart.setStartAngle(150);
        Popup popupChart=new Popup();
        popupChart.setAutoHide(true);
        Label labelChart = new Label("");
        labelChart.setStyle("-fx-font: bold 20 Arial;-fx-text-fill:brown");
        popupChart.getContent().addAll(labelChart);
        for (PieChart.Data data : chart.getData()) {
            data.getNode().addEventHandler(MouseEvent.MOUSE_PRESSED,
                   (MouseEvent e)-> {
                            labelChart.setText(String.valueOf(data.getPieValue()) + "%");
                            popupChart.setX(e.getScreenX());
                            popupChart.setY(e.getScreenY());
                            popupChart.show(primaryStage);
                         });}
        chart.addEventHandler(MouseEvent.DRAG_DETECTED,
                (MouseEvent e)-> {
                        chart.setStartAngle(chart.getStartAngle()+2);
                    });

      //  root.getChildren().add(chart);

        ObservableList<String> category =FXCollections.observableArrayList("Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь");
        CategoryAxis xAxis = new CategoryAxis(category);
        xAxis.setLabel("Месяцы");
        xAxis.setTickLabelFill(Color.BROWN);
        xAxis.setTickLabelGap(10);
        xAxis.setTickLength(20);
        xAxis.setEndMargin(30);
        xAxis.setGapStartAndEnd(false);
        xAxis.setStartMargin(30);
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Температура");
        yAxis.setTickLabelFill(Color.BROWN);
        yAxis.setTickLabelGap(10);
        yAxis.setSide(Side.LEFT);
        yAxis.setAutoRanging(false);
      //  yAxis.setUpperBound(35);
        yAxis.setMinorTickCount(3);


     //   AreaChart<String,Number> chartArea = new AreaChart<String,Number>(xAxis,yAxis);

        StackedAreaChart<String,Number> chartArea = new StackedAreaChart<String,Number>(xAxis,yAxis);

        chartArea.setCreateSymbols(false);

        chartArea.setLayoutX(50);
        chartArea.setLayoutY(10);
        chartArea.setCursor(Cursor.CROSSHAIR);
        chartArea.setStyle("-fx-font:bold 14 Arial; -fx-text-fill:brown;");
        chartArea.setPrefSize(500, 400);
        chartArea.setTitle("Климат Хургады");
        chartArea.setTitleSide(Side.TOP);
        chartArea.setLegendVisible(true);
        chartArea.setLegendSide(Side.BOTTOM);
        chartArea.setAlternativeColumnFillVisible(true);
        chartArea.setAlternativeRowFillVisible(false);
        chartArea.setHorizontalGridLinesVisible(true);
        chartArea.setVerticalGridLinesVisible(true);
        XYChart.Series seriesAirTem= new XYChart.Series();
        seriesAirTem.setName("Температура воздуха");
        XYChart.Data data1=new XYChart.Data(category.get(0),21);
        Text text1=new Text("21");
        text1.setFill(Color.BROWN);
        data1.setNode(text1);
        XYChart.Data data7=new XYChart.Data(category.get(6),33);
        Text text7=new Text("33");
        text7.setFill(Color.BROWN);
        data7.setNode(text7);
        XYChart.Data data12=new XYChart.Data(category.get(11),23);
        Text text12=new Text("23");
        text12.setFill(Color.BROWN);
        data12.setNode(text12);
        seriesAirTem.getData().addAll(data1, new XYChart.Data(category.get(1),22), new XYChart.Data(category.get(2),24), new XYChart.Data(category.get(3),27), new XYChart.Data(category.get(4),30), new XYChart.Data(category.get(5),32), data7, new XYChart.Data(category.get(7),33), new XYChart.Data(category.get(8),31), new XYChart.Data(category.get(9),29), new XYChart.Data(category.get(10),26),data12);
        XYChart.Series seriesWaterTem= new XYChart.Series();
        seriesWaterTem.setName("Температура воды");
        seriesWaterTem.getData().addAll(new XYChart.Data(category.get(0),20), new XYChart.Data(category.get(1),18), new XYChart.Data(category.get(2),20), new XYChart.Data(category.get(3),23), new XYChart.Data(category.get(4),26), new XYChart.Data(category.get(5),29), new XYChart.Data(category.get(6),31), new XYChart.Data(category.get(7),30), new XYChart.Data(category.get(8),29), new XYChart.Data(category.get(9),26), new XYChart.Data(category.get(10),24), new XYChart.Data(category.get(11),22));
        chartArea.getData().addAll(seriesAirTem, seriesWaterTem);
        DropShadow effectChart=new DropShadow();
        effectChart.setOffsetX(5);
        effectChart.setOffsetY(5);
        seriesWaterTem.getNode().setEffect(effectChart);

      //  root.getChildren().add(chartArea);

        ObservableList<String> categoryBar =FXCollections.observableArrayList("2008","2009","2010");
        CategoryAxis xAxisBar = new CategoryAxis(categoryBar);
        xAxisBar.setLabel("Год");
        xAxisBar.setTickLabelFill(Color.BROWN);
        xAxisBar.setTickLabelGap(10);
        xAxisBar.setTickLength(20);
        xAxisBar.setGapStartAndEnd(true);

        NumberAxis yAxisBar = new NumberAxis();
        yAxisBar.setLabel("Миллиардов долларов США");
        yAxisBar.setTickLabelFill(Color.BROWN);
        yAxisBar.setTickLabelGap(10);
        yAxisBar.setSide(Side.LEFT);
        yAxisBar.setAutoRanging(false);
        yAxisBar.setUpperBound(1000.0);
        yAxisBar.setMinorTickCount(0);
        yAxisBar.setTickUnit(100.0);

      //  BarChart<String,Number> chartBar = new BarChart<String,Number>(xAxisBar,yAxisBar);

        StackedBarChart<String,Number> chartBar = new StackedBarChart<String,Number>(xAxisBar,yAxisBar);

        chartBar.setLayoutX(50);
        chartBar.setLayoutY(10);
        chartBar.setCursor(Cursor.CROSSHAIR);
        chartBar.setStyle("-fx-font:bold 14 Arial; -fx-text-fill:brown;");
        chartBar.setPrefSize(500, 500);
        chartBar.setTitle("Внешний долг и резервы России");
        chartBar.setTitleSide(Side.TOP);
        chartBar.setLegendVisible(true);
        chartBar.setLegendSide(Side.BOTTOM);
        chartBar.setAlternativeColumnFillVisible(false);
        chartBar.setAlternativeRowFillVisible(false);
        chartBar.setHorizontalGridLinesVisible(true);
        chartBar.setVerticalGridLinesVisible(false);
     //   chartBar.setBarGap(5);
        chartBar.setCategoryGap(50);
        XYChart.Series seriesD= new XYChart.Series();
        seriesD.setName("Консолидированный внешний долг России");
        seriesD.getData().addAll(new XYChart.Data(categoryBar.get(0),463.9), new XYChart.Data(categoryBar.get(1),480.5), new XYChart.Data(categoryBar.get(2),467.2));
        XYChart.Series seriesC= new XYChart.Series();
        seriesC.setName("Международные резервы России");
        seriesC.getData().addAll(new XYChart.Data(categoryBar.get(0),478.8), new XYChart.Data(categoryBar.get(1),426.3), new XYChart.Data(categoryBar.get(2),439.5));
        chartBar.getData().addAll(seriesD, seriesC);

      //  root.getChildren().add(chartBar);

        NumberAxis xAxisBub = new NumberAxis();
        xAxisBub.setLabel("Год");
        xAxisBub.setTickLabelFill(Color.BROWN);
        xAxisBub.setTickLabelGap(10);
        xAxisBub.setTickLength(20);
        xAxisBub.setAutoRanging(false);
        xAxisBub.setUpperBound(2011);
        xAxisBub.setLowerBound(2007);
        xAxisBub.setMinorTickCount(0);
        xAxisBub.setTickUnit(1);
        NumberAxis yAxisBub = new NumberAxis();
        yAxisBub.setLabel("Миллионов абонентов");
        yAxisBub.setTickLabelFill(Color.BROWN);
        yAxisBub.setTickLabelGap(10);
        yAxisBub.setSide(Side.LEFT);
        yAxisBub.setAutoRanging(false);
        yAxisBub.setUpperBound(80.0);
        yAxisBub.setMinorTickCount(0);
        yAxisBub.setTickUnit(10.0);
        yAxisBub.setLowerBound(30.0);
        BubbleChart<Number,Number> chartBub = new BubbleChart<Number,Number>(xAxisBub,yAxisBub);
        chartBub.setLayoutX(50);
        chartBub.setLayoutY(10);
        chartBub.setCursor(Cursor.CROSSHAIR);
        chartBub.setStyle("-fx-font:bold 14 Arial; -fx-text-fill:brown;");
        chartBub.setPrefSize(400, 400);
        chartBub.setTitle("Рынок сотовой связи России");
        chartBub.setTitleSide(Side.TOP);
        chartBub.setLegendVisible(true);
        chartBub.setLegendSide(Side.BOTTOM);
        chartBub.setAlternativeColumnFillVisible(false);
        chartBub.setAlternativeRowFillVisible(false);
        chartBub.setHorizontalGridLinesVisible(false);
        chartBub.setVerticalGridLinesVisible(true);
        XYChart.Series seriesMTC= new XYChart.Series();
        seriesMTC.setName("MTC");
        XYChart.Data dataMTC1=new XYChart.Data(2008, 62, 0.62);
        XYChart.Data dataMTC2=new XYChart.Data(2009, 65, 0.65);
        XYChart.Data dataMTC3=new XYChart.Data(2010,71, 0.71);
        seriesMTC.getData().addAll(dataMTC1,dataMTC2,dataMTC3);
        XYChart.Series seriesB= new XYChart.Series();
        seriesB.setName("Билайн");
        XYChart.Data dataB1=new XYChart.Data(2008, 45, 0.45);
        XYChart.Data dataB2=new XYChart.Data(2009, 49, 0.49);
        XYChart.Data dataB3=new XYChart.Data(2010, 52, 0.52);
        seriesB.getData().addAll(dataB1, dataB2, dataB3);
        XYChart.Series seriesM= new XYChart.Series();
        seriesM.setName("Мегафон");
        XYChart.Data dataM1=new XYChart.Data(2008, 42, 0.42);
        XYChart.Data dataM2=new XYChart.Data(2009, 44, 0.44);
        XYChart.Data dataM3=new XYChart.Data(2010, 56, 0.56);
        seriesM.getData().addAll(dataM1, dataM2, dataM3);
        chartBub.getData().addAll(seriesMTC, seriesB, seriesM);
        dataMTC1.getNode().setScaleY(5);
        dataMTC2.getNode().setScaleY(5);
        dataMTC3.getNode().setScaleY(5);
        dataB1.getNode().setScaleY(5);
        dataB2.getNode().setScaleY(5);
        dataB3.getNode().setScaleY(5);
        dataM1.getNode().setScaleY(5);
        dataM2.getNode().setScaleY(5);
        dataM3.getNode().setScaleY(5);

      //  root.getChildren().add(chartBub);

        ObservableList<String> categoryL =FXCollections.observableArrayList("Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь");
        CategoryAxis xAxisL = new CategoryAxis(category);
        xAxisL.setLabel("Месяцы");
        xAxisL.setTickLabelFill(Color.BROWN);
        xAxisL.setTickLabelGap(10);
        xAxisL.setTickLength(20);
        xAxisL.setEndMargin(30);
        xAxisL.setGapStartAndEnd(false);
        xAxisL.setStartMargin(30);
        NumberAxis yAxisL = new NumberAxis();
        yAxisL.setLabel("Температура");
        yAxisL.setTickLabelFill(Color.BROWN);
        yAxisL.setTickLabelGap(10);
        yAxisL.setSide(Side.LEFT);
        yAxisL.setAutoRanging(false);
        yAxisL.setUpperBound(35);
        yAxisL.setMinorTickCount(3);
        LineChart<String,Number> chartL = new LineChart<String,Number>(xAxisL,yAxisL);
        chartL.setLayoutX(50);
        chartL.setLayoutY(10);
        chartL.setCursor(Cursor.CROSSHAIR);
        chartL.setStyle("-fx-font:bold 14 Arial; -fx-text-fill:brown;");
        chartL.setPrefSize(500, 400);
        chartL.setTitle("Климат Хургады");
        chartL.setTitleSide(Side.TOP);
        chartL.setLegendVisible(true);
        chartL.setLegendSide(Side.BOTTOM);
        chartL.setAlternativeColumnFillVisible(true);
        chartL.setAlternativeRowFillVisible(false);
        chartL.setHorizontalGridLinesVisible(true);
        chartL.setVerticalGridLinesVisible(true);
        chartL.setCreateSymbols(false);
        XYChart.Series seriesAirTemL= new XYChart.Series();
        seriesAirTemL.setName("Температура воздуха");
        XYChart.Data data1L=new XYChart.Data(categoryL.get(0),21);
        Text text1L=new Text("21");
        text1L.setFill(Color.BROWN);
        data1L.setNode(text1L);
        XYChart.Data data7L=new XYChart.Data(categoryL.get(6),33);
        Text text7L=new Text("33");
        text7L.setFill(Color.BROWN);
        data7L.setNode(text7L);
        XYChart.Data data12L=new XYChart.Data(categoryL.get(11),23);
        Text text12L=new Text("23");
        text12L.setFill(Color.BROWN);
        data12L.setNode(text12L);
        seriesAirTemL.getData().addAll(data1L, new XYChart.Data(categoryL.get(1),22), new XYChart.Data(categoryL.get(2),24), new XYChart.Data(categoryL.get(3),27), new XYChart.Data(categoryL.get(4),30), new XYChart.Data(categoryL.get(5),32), data7L, new XYChart.Data(categoryL.get(7),33), new XYChart.Data(categoryL.get(8),31), new XYChart.Data(categoryL.get(9),29), new XYChart.Data(categoryL.get(10),26),data12L);
        XYChart.Series seriesWaterTemL= new XYChart.Series();
        seriesWaterTemL.setName("Температура воды");
        seriesWaterTemL.getData().addAll(new XYChart.Data(categoryL.get(0),20), new XYChart.Data(categoryL.get(1),18), new XYChart.Data(categoryL.get(2),20), new XYChart.Data(categoryL.get(3),23), new XYChart.Data(categoryL.get(4),26), new XYChart.Data(categoryL.get(5),29), new XYChart.Data(categoryL.get(6),31), new XYChart.Data(categoryL.get(7),30), new XYChart.Data(categoryL.get(8),29), new XYChart.Data(categoryL.get(9),26), new XYChart.Data(categoryL.get(10),24), new XYChart.Data(categoryL.get(11),22));
        chartL.getData().addAll(seriesWaterTemL, seriesAirTemL);

      //  root.getChildren().add(chartL);

        NumberAxis xAxisS = new NumberAxis();
        xAxisS.setLabel("Сигарет на человека в год");
        xAxisS.setTickLabelFill(Color.BROWN);
        xAxisS.setTickLabelGap(10);
        xAxisS.setTickLength(20);
        xAxisS.setAutoRanging(false);
        xAxisS.setUpperBound(5000);
        xAxisS.setLowerBound(1000);
        xAxisS.setMinorTickCount(0);
        xAxisS.setTickUnit(500);
        NumberAxis yAxisS = new NumberAxis();
        yAxisS.setLabel("Смертей от рака лекгих\n на 100 тыс. человек");
        yAxisS.setTickLabelFill(Color.BROWN);
        yAxisS.setTickLabelGap(10);
        yAxisS.setSide(Side.LEFT);
        yAxisS.setAutoRanging(false);
        yAxisS.setUpperBound(300);
        yAxisS.setMinorTickCount(0);
        yAxisS.setTickUnit(50);
        ScatterChart<Number,Number> chartS = new ScatterChart<Number,Number>(xAxisS,yAxisS);
        chartS.setLayoutX(50);
        chartS.setLayoutY(10);
        chartS.setCursor(Cursor.CROSSHAIR);
        chartS.setStyle("-fx-font:bold 14 Arial; -fx-text-fill:brown;");
        chartS.setPrefSize(500, 400);
        chartS.setTitle("Зависимость смертности \n от интенсивности курения");
        chartS.setTitleSide(Side.TOP);
        chartS.setLegendVisible(true);
        chartS.setLegendSide(Side.BOTTOM);
        chartS.setAlternativeColumnFillVisible(true);
        chartS.setAlternativeRowFillVisible(false);
        chartS.setHorizontalGridLinesVisible(true);
        chartS.setVerticalGridLinesVisible(true);
        XYChart.Series seriesMS= new XYChart.Series();
        seriesMS.setName("Мужчины");
        seriesMS.getData().addAll(new XYChart.Data(2000,75), new XYChart.Data(2300,60), new XYChart.Data(2500,100), new XYChart.Data(3000,155), new XYChart.Data(3500,140), new XYChart.Data(4000,175),new XYChart.Data(4200,180));
        XYChart.Series seriesFS= new XYChart.Series();
        seriesFS.setName("Женщины");
        seriesFS.getData().addAll(new XYChart.Data(2000,60), new XYChart.Data(2300,78), new XYChart.Data(2500,120), new XYChart.Data(3000,125), new XYChart.Data(3500,160), new XYChart.Data(4000,150),new XYChart.Data(4200,210));
        chartS.getData().addAll(seriesMS, seriesFS);

      //  root.getChildren().add(chartS);

        ProgressBar pbTask=new ProgressBar();
        pbTask.setLayoutX(20);
        pbTask.setLayoutY(50);
        pbTask.setCursor(Cursor.TEXT);
        DropShadow effectTask=new DropShadow();
        effectTask.setOffsetX(8);
        effectTask.setOffsetY(8);
        pbTask.setEffect(effect);
        pbTask.setTooltip(new Tooltip("Индикатор выполнения задачи"));
        pbTask.setPrefSize(200,30);
        pbTask.setProgress(0.0);

        Button btnSTask=new Button("Start");
        btnSTask.setLayoutX(20);
        btnSTask.setLayoutY(100);
        btnSTask.setStyle("-fx-font: 16pt Arial;");
        btnSTask.setOnAction((ActionEvent e)-> {
                Task task = new Task<Void>() {
                    @Override
                    protected Void call() throws Exception {
                        int max = 10;
                        for (int i = 1; i <= max; i++) {
                            updateProgress(i,max);
                            Thread.sleep(200);
                        }
                        return null;
                    }
                    @Override
                    protected void updateProgress(long workDone, long max){
                        pbTask.setProgress((double)workDone/(double)max);
                    }};

                //new Thread(task).start();
                ExecutorService es = Executors.newSingleThreadExecutor ();
                // es.submit (task);
                //  es.shutdown ();

                Service service=new Service<Void>() {
                    @Override
                    protected Task createTask() {
                        return task;
                    }};
                service.start();
            });
        Button btnRTask=new Button("Reset");
        btnRTask.setLayoutX(100);
        btnRTask.setLayoutY(100);
        btnRTask.setStyle("-fx-font: 16pt Arial;");
        btnRTask.setOnAction((ActionEvent e)-> {
                pbTask.setProgress(0.0);
            });

       // root.getChildren().addAll(pbTask, btnSTask, btnRTask);


        primaryStage.setTitle("JavaFX App");
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    Pagination pagination;
    String[] textPages = new String[]{
            "this is a test 1",
            "this is a test 2",
            "this is a test 3",
            "this is a test 4",
            "this is a test 5",
            "this is a test 6",
            "this is a test 7",
            "this is a test 8",
            "this is a test 8",
    };

    public int itemsPerPage() {
        return 1;
    }

    public VBox createPage(int pageIndex) {
        VBox box = new VBox(5);
        int page = pageIndex * itemsPerPage();
        for (int i = page; i < page + itemsPerPage(); i++) {
            TextArea text = new TextArea(textPages[i]);
            text.setWrapText(true);
            box.getChildren().add(text);
        }
        return box;
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static class Hotel {

        private StringProperty name;
        private StringProperty resort;
        private StringProperty category;
        private DoubleProperty rate;

        public Hotel(String name, String resort, String category, double rate) {
            this.name = new SimpleStringProperty(name);
            this.resort = new SimpleStringProperty(resort);
            this.category = new SimpleStringProperty(category);
            this.rate=new SimpleDoubleProperty(rate);
        }

        public String getName() {
            return name.get();
        }

        public StringProperty nameProperty() {
            return name;
        }

        public void setName(String name) {
            this.name.set(name);
        }

        public String getResort() {
            return resort.get();
        }

        public StringProperty resortProperty() {
            return resort;
        }

        public void setResort(String resort) {
            this.resort.set(resort);
        }

        public String getCategory() {
            return category.get();
        }

        public StringProperty categoryProperty() {
            return category;
        }

        public void setCategory(String category) {
            this.category.set(category);
        }

        public Double getRate() {
            return rate.getValue();
        }

        public DoubleProperty rateProperty() {
            return rate;
        }

        public void setRate(double rate) {
            this.rate.set(rate);
        }

        public String toString(){
            return this.getName();
        }
    }

}
