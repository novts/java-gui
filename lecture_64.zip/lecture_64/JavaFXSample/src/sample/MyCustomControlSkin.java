package sample;

import com.sun.javafx.scene.control.behavior.BehaviorBase;
import com.sun.javafx.scene.control.skin.LabelSkin;

public class MyCustomControlSkin extends LabelSkin {
    private MyCustomControlBehavior behavior;

    public MyCustomControlSkin(MyCustomControl control) {
        super(control);
        control.setText("This is Custom UI");
        behavior = new MyCustomControlBehavior(control);

    }

    public class MyCustomControlBehavior  extends BehaviorBase {

        public MyCustomControlBehavior(MyCustomControl control) {
            super(control, null);
        }
    }
}
