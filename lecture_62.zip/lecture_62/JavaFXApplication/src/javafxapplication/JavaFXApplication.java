/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Tooltip;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Тимур
 */
public class JavaFXApplication extends Application {
    
    @Override
    public void start(Stage primaryStage) {
       final Button btn = new Button();
        btn.setText("Say 'Hello World'");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Height "+btn.getHeight()+" Width "+btn.getWidth());
                System.out.println("Layout Height "+btn.getLayoutBounds().getHeight()+" Layout Width "+btn.getLayoutBounds().getWidth());
                System.out.println("Local Height "+btn.getBoundsInLocal().getHeight()+" Local Width "+btn.getBoundsInLocal().getWidth());
                System.out.println("Parent Height "+btn.getBoundsInParent().getHeight()+" Parent Width "+btn.getBoundsInParent().getWidth());
            }
        });
        
        Image icon = new Image(getClass().getResourceAsStream("icon.jpg"));
        ImageView imv=new ImageView(icon);
        imv.setFitHeight(50);
        imv.setFitWidth(50);
      //  btn.setGraphic(imv);
        
        btn.setLayoutX(20);
        btn.setLayoutY(20);
        
       // btn.setStyle("-fx-font:  bold italic 10pt Helvetica;");
      //  btn.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 10));
        btn.setStyle("-fx-font:  bold italic 12pt Arial;-fx-text-fill: #660000; -fx-background-color: #ff99ff; -fx-border-width: 3px; -fx-border-radius: 30;-fx-background-radius: 30;-fx-border-color: #660066;" );       

        btn.setPrefSize(300,100);
        btn.setMaxSize(400, 100);
        btn.setMinSize(100, 50);
        
        //btn.setBlendMode(BlendMode.DARKEN);        
        Circle clip =new Circle(75,53,80);         
       // btn.setClip(clip);        
     //   btn.setCursor(Cursor.CLOSED_HAND); 
        DropShadow effect=new DropShadow();
        effect.setOffsetX(10);
        effect.setOffsetY(10);
      //  btn.setEffect(effect);             
     //   btn.setManaged(false);
     //   btn.resize(200, 40);
       
      //   btn.setFocusTraversable(true);
        /*     
          btn.setMouseTransparent(true);
          btn.setOpacity(0.5);
          btn.setRotate(10);
          btn.setLayoutX(80);        
          btn.setScaleX(1.8);         
          btn.setLayoutY(170);        
          btn.setTranslateZ(-50);               
          btn.setTooltip(new Tooltip("Это кнопка тестирования свойств класса Button"));        
          btn.setAlignment(Pos.CENTER);
          btn.setContentDisplay(ContentDisplay.RIGHT);
          btn.setUnderline(true);
          btn.setWrapText(true); 
          btn.setCancelButton(true);  */
        //  btn.toBack();

        //Group root = new Group();
       // StackPane root = new StackPane();
       HBox root = new HBox();
        root.getChildren().add(btn);
        
       Scene scene = new Scene(root, 400, 400, Color.LIGHTGREEN);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
