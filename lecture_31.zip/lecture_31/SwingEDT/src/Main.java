import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ExecutionException;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    private static void createAndShowGUI() {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);

        JButton button = new JButton("Click");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
/*
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            Thread.sleep(3000);
                            EventQueue.invokeLater(new Runnable() {
                                public void run() {
                                    String label = button.getText();
                                    button.setText(label + "1");
                                }
                            });
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();*/
                frame.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
                SwingWorker worker = new SwingWorker() {
                    protected String doInBackground() throws InterruptedException {
                        Thread.sleep(3000);
                        return "1";
                    }
                    protected void done() {
                        String label = button.getText();
                        try {
                            button.setText(label + get());
                        } catch (InterruptedException e1) {
                            e1.printStackTrace();
                        } catch (ExecutionException e1) {
                            e1.printStackTrace();
                        }
                        frame.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                    }
                };
                worker.execute();
            }
        });
        frame.add(button);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
