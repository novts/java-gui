import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    private static void createAndShowGUI() {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new FlowLayout());

        final ProgressMonitor progressMonitor = new ProgressMonitor(frame,
                "Running a Long Task", "", 0, 100);
        JButton button = new JButton("Button");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingWorker worker = new SwingWorker<String, Integer>() {
                    @Override
                    protected String doInBackground() throws InterruptedException {
                        for(int i=0; i<100; i++) {
                            Thread.sleep(100);
                            publish(i);
                            setProgress(i);
                        }
                        return "Click";
                    }
                    @Override
                    protected void process(List<Integer> chunks) {
                        progressMonitor.setNote("Progress " + chunks.get(chunks.size() - 1)+"%");
                    }
                    protected void done() {
                        try {
                            button.setText("Button" + get());
                            progressMonitor.setProgress(100);
                        } catch (InterruptedException e1) {
                            e1.printStackTrace();
                        } catch (ExecutionException e1) {
                            e1.printStackTrace();
                        }
                    }
                };
                worker.addPropertyChangeListener(new PropertyChangeListener() {
                    public  void propertyChange(PropertyChangeEvent evt) {
                        if ("progress".equals(evt.getPropertyName())) {
                            progressMonitor.setProgress((Integer)evt.getNewValue());
                        }
                    }
                });
                worker.execute();
            }
        });


        frame.add(button);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}

