import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static class MenuItemAction extends AbstractAction {
        Component parentComponent;

        public MenuItemAction(Component parentComponent) {
            super("Exit");
            putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_Q, Event.CTRL_MASK));
            this.parentComponent = parentComponent;
        }

        public void actionPerformed(ActionEvent actionEvent) {
            int a = JOptionPane.showConfirmDialog(parentComponent, "Are you sure?");
            if(a==JOptionPane.YES_OPTION){
                System.exit(0);
            }
        }
    }

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new FlowLayout());

        JMenuBar mb = new JMenuBar();
        frame.setJMenuBar(mb);

       // mb.add(Box.createHorizontalGlue());

        JMenu file = new JMenu("<html><u>F</u>ile");

        file.setMnemonic(KeyEvent.VK_F);

        mb.add(file);
        JMenuItem open = file.add("Open");
        file.addSeparator();

        JMenuItem exitP = new JMenuItem(new MenuItemAction(frame));
        file.add(exitP);

        JMenuItem exit = file.add("Exit");

        exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, Event.CTRL_MASK));

        exit.setMnemonic(KeyEvent.VK_E);

        exit.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                System.exit(0);
            }
        });

        file.addSeparator();

        final JCheckBoxMenuItem showMenu = new JCheckBoxMenuItem(
                "Show Exit", true);
        showMenu.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {

                if(showMenu.getState()){
                    file.add(exitP);
                } else {
                    file.remove(exitP);
                }
            }
        });

        file.add(showMenu);

        file.addSeparator();

        JRadioButtonMenuItem rbm1 = new JRadioButtonMenuItem("Doc");
        rbm1.setActionCommand("Doc");
        JRadioButtonMenuItem rbm2 = new JRadioButtonMenuItem("PDF");
        rbm2.setActionCommand("PDF");
        ButtonGroup bg = new ButtonGroup();
        bg.add(rbm1);
        bg.add(rbm2);
        file.add(rbm1);
        file.add(rbm2);
        rbm1.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if(bg.getSelection().getActionCommand().equals("Doc")){
                    System.out.println("Handle Doc");
                } else {
                    System.out.println("Handle PDF");
                }
            }
        });


        final JLabel label = new JLabel("My Text");
        frame.add(label);

        final JPopupMenu popupmenu = new JPopupMenu("Edit");
        JMenuItem cut = new JMenuItem("Cut");
        JMenuItem copy = new JMenuItem("Copy");
        JMenuItem paste = new JMenuItem("Paste");
        popupmenu.add(cut);
        popupmenu.add(copy);
        popupmenu.add(paste);
        label.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                if(e.isPopupTrigger())
                    popupmenu.show(e.getComponent(),e.getX(),e.getY());
            }

            public void mouseReleased(MouseEvent e) {
                if(e.isPopupTrigger())
                    popupmenu.show(e.getComponent(),e.getX(),e.getY());
            }

        });


        frame.setVisible(true);
    }
}
