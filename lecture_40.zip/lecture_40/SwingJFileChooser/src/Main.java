import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new FlowLayout());

        JMenuBar mb = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem open = new JMenuItem("Open File");
        JMenuItem save = new JMenuItem("Save File");
        file.add(open);
        file.add(save);
        mb.add(file);
        frame.setJMenuBar(mb);

       final JFileChooser  fileDialog = new JFileChooser("C:");
        fileDialog.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        fileDialog.setFileHidingEnabled(false);
        fileDialog.setMultiSelectionEnabled(true);
        FileFilter filter = new FileNameExtensionFilter("Text&Image files", "txt", "jpg", "jpeg", "png", "bmp");
        fileDialog.setAcceptAllFileFilterUsed(false);
        fileDialog.addChoosableFileFilter(filter);

        fileDialog.setAccessory(new MyAccessory(fileDialog));


        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int returnVal = fileDialog.showOpenDialog(frame);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    if(fileDialog.isMultiSelectionEnabled()){
                        java.io.File files[] = fileDialog.getSelectedFiles();
                        for(java.io.File f:files){
                            System.out.println("File Path " + f.getPath());
                        }
                    }else {
                        java.io.File file = fileDialog.getSelectedFile();
                        System.out.println("File Path " + file.getPath());
                    }
                }
            }
        });

        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int returnVal = fileDialog.showSaveDialog(frame);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    java.io.File file = fileDialog.getSelectedFile();
                    System.out.println("File Path " + file.getPath());
                }
            }
        });

        frame.setVisible(true);
    }

   static public class MyAccessory extends JComponent implements PropertyChangeListener {

       String path="";

        public MyAccessory(JFileChooser chooser) {
            chooser.addPropertyChangeListener(this);
            setPreferredSize(new Dimension(100, 100));
        }
        public void propertyChange(PropertyChangeEvent evt) {
            if (JFileChooser.SELECTED_FILE_CHANGED_PROPERTY.equals(evt.getPropertyName())) {
                JFileChooser chooser = (JFileChooser) evt.getSource();
                // Get the new selected file
               File newFile = (File) evt.getNewValue();
               path=newFile.getPath();
               System.out.println(path);
                repaint();
            }
        }
        public void paint(Graphics g) {
            // Paint a preview of the selected file
            g.drawString(path,10,10);
        }
    }
}
