import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.DefaultFormatter;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.DateFormatSymbols;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {
    public static void main(String[] args) {

        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setLayout(new FlowLayout());

        String[] days = new DateFormatSymbols().getWeekdays();
       // SpinnerModel model = new SpinnerListModel(Arrays.asList(days).subList(1, 8));


        Calendar cal = Calendar.getInstance();
        Date now = cal.getTime();
        cal.add(Calendar.YEAR, -50);
        Date startDate = cal.getTime();
        cal.add(Calendar.YEAR, 100);
        Date endDate = cal.getTime();
       // SpinnerModel model = new SpinnerDateModel(now, startDate, endDate, Calendar.YEAR);

        SpinnerModel model =
                new SpinnerNumberModel(5, //initial value
                        0, //minimum value
                        10, //maximum value
                        1); //step


        JSpinner spinner = new JSpinner(model);

        spinner.setPreferredSize(new Dimension(100,30));

        JSpinner.DefaultEditor spinnerEditor = (JSpinner.DefaultEditor)spinner.getEditor();
        spinnerEditor.getTextField().setHorizontalAlignment(JTextField.CENTER);

        final JTextField formattedTextField = spinnerEditor.getTextField();
        formattedTextField.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                if(evt.getNewValue() instanceof String)
                    System.out.println("Value : " + evt.getNewValue());

                if(evt.getNewValue() instanceof Date)
                    System.out.println("Value : " + evt.getNewValue());

                if(evt.getNewValue() instanceof Number)
                    System.out.println("Value : " + evt.getNewValue());
        }

        });

        spinner.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
               // System.out.println("Value : " + ((JSpinner)e.getSource()).getValue());
            }
        });

        frame.add(spinner);
        frame.add(new Button("Click"));
        frame.setVisible(true);
    }
}
