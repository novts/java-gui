import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;

import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setLayout(new FlowLayout());

        final JButton btn = new JButton("Click");
        btn.setPreferredSize(new Dimension(100,50));

        JSlider slider = new JSlider(JSlider.HORIZONTAL,0,100,10);
        slider.setMajorTickSpacing(20);
        slider.setMinorTickSpacing(5);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setLabelTable(slider.createStandardLabels(20, 0));
        slider.setSnapToTicks(true);
       // slider.setPaintTrack(false);

        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int f = (Integer)((JSlider)e.getSource()).getValue();
                int width=100 + f;
                btn.setPreferredSize(new Dimension(width,btn.getHeight()));
                btn.updateUI();
            }
        });

        frame.add(btn);
        frame.add(slider);
        frame.setVisible(true);
    }
}
