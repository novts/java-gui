import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) {
        JFrame frame = new JFrame("JDialog Example");
        frame.setLayout( new FlowLayout() );
        frame.setSize(300, 300);

        MyGlassPane glass = new MyGlassPane(new Point(100,100));
        frame.setGlassPane(glass);
       // glass.setVisible(true);

        JLayeredPane lp = frame.getLayeredPane();

        // Create 3 buttons
        JButton top = new JButton();
        top.setBackground(Color.white);
        top.setBounds(20, 20, 50, 50);
        JButton middle = new JButton();
        middle.setBackground(Color.gray);
        middle.setBounds(40, 40, 50, 50);
        JButton bottom = new JButton();
        bottom.setBackground(Color.black);
        bottom.setBounds(60, 60, 50, 50);

        // Place the buttons in different layers
        lp.add(middle, new Integer(2));
        lp.add(top, new Integer(3));
        lp.add(bottom, new Integer(1));

        final JDialog d = new JDialog(frame , "Dialog Example", true);
        d.setLayout( new FlowLayout() );
        d.setSize(100,100);
        d.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        d.add( new JLabel ("Message to User"));

       // MyJDialog myd = new MyJDialog(frame, "MyDialog Example", "Message to User", 10,10);


        JButton b = new JButton ("Show Dialog");
        b.addActionListener ( new ActionListener()
        {
            public void actionPerformed( ActionEvent e )
            {
               // myd.setVisible(true);
                d.setVisible(true);
            }
        });

        frame.add(b);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

   static class MyGlassPane extends JComponent {
       Point point;

       public MyGlassPane(Point p) {
           point = p;
       }

       protected void paintComponent(Graphics g) {
           if (point != null) {
               g.setColor(Color.red);
               g.fillOval(point.x - 10, point.y - 10, 20, 20);
           }
       }
   }


    static public class MyJDialog extends JDialog {

        public MyJDialog(JFrame parent, String title, String message, int x, int y) {
            super(parent, title);
            setLocation(x, y);
            JPanel messagePane = new JPanel();
            messagePane.add(new JLabel(message));
            getContentPane().add(messagePane);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            pack();
            setVisible(false);
        }

        // override the createRootPane inherited by the JDialog, to create the rootPane.
        // create functionality to close the window when "Escape" button is pressed
        public JRootPane createRootPane() {
            JRootPane rootPane = new JRootPane();
            KeyStroke stroke = KeyStroke.getKeyStroke("ESCAPE");
            Action action = new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    setVisible(false);
                    dispose();
                }
            };
            InputMap inputMap = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
            inputMap.put(stroke, "ESCAPE");
            rootPane.getActionMap().put("ESCAPE", action);
            return rootPane;
        }

    }
}
