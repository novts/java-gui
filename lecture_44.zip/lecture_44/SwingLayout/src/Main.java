import javax.swing.*;

import java.awt.*;

import static java.awt.Component.BOTTOM_ALIGNMENT;
import static java.awt.Component.TOP_ALIGNMENT;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Main {

    public static void main(String[] args) {
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(300,300);
       /* frame.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

        frame.add(new JButton("Click"));
        frame.add(new JLabel("Label"));
        frame.add(new JCheckBox("Check"));
        frame.add(new JComboBox());
        frame.add(new JTextField("Input", 10));

        frame.setLayout(new BorderLayout(10,10));

        frame.add(new JButton("North"), BorderLayout.NORTH);
        frame.add(new JButton("South"), BorderLayout.SOUTH);
        frame.add(new JButton("West"), BorderLayout.WEST);
        frame.add(new JButton("East"), BorderLayout.EAST);
        frame.add(new JButton("Center"));

        GridLayout layout = new GridLayout(0,3);
        layout.setHgap(10);
        layout.setVgap(10);

        CardLayout layout = new CardLayout(10,10);
        Container c = frame.getContentPane();
        c.setLayout(layout);
        frame.add(new JButton("Button 1"));
        frame.add(new JButton("Button 2"));
        frame.add(new JButton("Button 3"));
        frame.add(new JButton("Button 4"));
        frame.add(new JButton("Button 5"), "Button 5");

        layout.show(c, "Button 5");


        GridBagLayout layout = new GridBagLayout();
        frame.setLayout(layout);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        frame.add(new JButton("Button 1"),gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        frame.add(new JButton("Button 2"),gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.ipady = 20;
        gbc.gridx = 0;
        gbc.gridy = 1;
        frame.add(new JButton("Button 3"),gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        frame.add(new JButton("Button 4"),gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 2;
        frame.add(new JButton("Button 5"),gbc);

        GroupLayout layout = new GroupLayout(frame.getContentPane());
        frame.getContentPane().setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        JButton btn1 = new JButton("Button 1");
        JButton btn2 = new JButton("Button 2");
        JButton btn3 = new JButton("Button 3");

        layout.setHorizontalGroup(layout.createSequentialGroup()
                .addComponent(btn1)
                .addGroup(layout.createParallelGroup(
                                GroupLayout.Alignment.LEADING)
                                .addComponent(btn2)
                                .addComponent(btn3)));

        layout.setVerticalGroup(layout.createSequentialGroup()
                .addComponent(btn1)
                .addComponent(btn2)
                .addComponent(btn3));

        BoxLayout layout = new BoxLayout (frame.getContentPane(), BoxLayout.Y_AXIS);
        frame.getContentPane().setLayout(layout);

        for (int i = 0;i<5;i++) {
         JButton   button = new JButton ("Button " + (i + 1));
            frame.add (button);
        }


        JLabel label1 = new JLabel( "A LABEL" );
        label1.setOpaque( true );
        label1.setBackground( Color.RED );
        label1.setForeground( Color.WHITE );
        label1.setAlignmentY( TOP_ALIGNMENT );
        JLabel label2 = new JLabel( "ANOTHER LABEL" );
        label2.setOpaque( true );
        label2.setBackground( Color.BLUE );
        label2.setForeground( Color.WHITE );
        label2.setAlignmentY( BOTTOM_ALIGNMENT );
        Box box = Box.createHorizontalBox( );
        box.add( Box.createGlue());
        box.add( label1 );
       // box.add( Box.createHorizontalStrut( 10 ) );
       // box.add( Box.createGlue());
        box.add( Box.createRigidArea( new Dimension( 250, 10 ) ) );
        box.add( label2 );
        box.add( Box.createGlue());

      //  Box box = Box.createVerticalBox( );
    //    box.add( label1 );
    //    box.add( label2 );

        frame.add(box);
     //   frame.add(box2);*/

        SpringLayout layout = new SpringLayout();
        frame.setLayout(layout);

        JLabel label = new JLabel("Label: ");
        JTextField textField = new JTextField("My Text Field", 15);
        frame.add(label);
        frame.add(textField);

        layout.putConstraint(SpringLayout.WEST, label,6,SpringLayout.WEST, frame.getContentPane());
        layout.putConstraint(SpringLayout.NORTH, label,6,SpringLayout.NORTH, frame.getContentPane());
        layout.putConstraint(SpringLayout.WEST, textField,6,SpringLayout.EAST, label);
        layout.putConstraint(SpringLayout.NORTH, textField,6,SpringLayout.NORTH, frame.getContentPane());
        layout.putConstraint(SpringLayout.EAST, frame.getContentPane(),6,SpringLayout.EAST, textField);
        layout.putConstraint(SpringLayout.SOUTH, frame.getContentPane(),6,SpringLayout.SOUTH, textField);

        //   frame.pack();
        frame.setVisible(true);
    }
}
